//  1394CameraControlSize.h: interface for the C1394CameraControlSize class.
//
//	Version 4.0
//
//	Copyright 5/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_1394CAMERACONTROLSIZE_H__6FF3FDE0_F5C5_11D3_98EB_E8AE80B6B274__INCLUDED_)
#define AFX_1394CAMERACONTROLSIZE_H__6FF3FDE0_F5C5_11D3_98EB_E8AE80B6B274__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class C1394Camera;

class __declspec(dllexport) C1394CameraControlSize  
{
friend C1394Camera;

public:
	bool Supported();
	bool ModeSupported(int mode);
	void SetColorCode(int code);
	void SetSize(int width, int height);
	void SetPosition(int left, int top);
	void Status();
	C1394CameraControlSize();
	virtual ~C1394CameraControlSize();

	int m_maxH;
	int m_maxV;
	int m_unitH;
	int m_unitV;
	int m_top;
	int m_left;
	int m_width;
	int m_height;
	int m_colorCode;
	bool m_colorCodes[7];


private:
	void SetBytesPerPacket(int bytes);
	void Update();

	C1394Camera* m_pCamera;
	int m_pixelsFrame;
	int m_bytesFrameHigh;
	int m_bytesFrameLow;
	int m_bytesPacketMin;
	int m_bytesPacketMax;
	int m_bytesPacket;
	int m_offset;
};

#endif // !defined(AFX_1394CAMERACONTROLSIZE_H__6FF3FDE0_F5C5_11D3_98EB_E8AE80B6B274__INCLUDED_)
