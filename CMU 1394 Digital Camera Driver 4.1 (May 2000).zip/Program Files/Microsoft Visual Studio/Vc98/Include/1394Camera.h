//  1394Camera.h: interface for the C1394Camera class.
//
//	Version 4.0
//
//	Copyright 5/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_1394CAMERA_H__557833A0_777B_11D3_98EB_8250F54AA371__INCLUDED_)
#define AFX_1394CAMERA_H__557833A0_777B_11D3_98EB_8250F54AA371__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <1394Api.h>

//#define ISOCH_ANY_CHANNEL	0xffffffff

#include "1394CameraControl.h"
#include "1394CameraControlTrigger.h"
#include "1394CameraControlSize.h"

class __declspec(dllexport) CString;

class __declspec(dllexport) C1394Camera  
{
friend class C1394CameraControlSize;  

public:
	int GetNode();
	void SelectCamera(int node);
	int GetNumberCameras();
	void YtoRGB(unsigned char *pBitmap);
	int GetVideoFormat();
	void SetVideoFormat(int format);
	void SetIris(int value);
	void SetFocus(int value);
	void SetZoom(int value);
	int GetMaxSpeed();
	int StopImageCapture();
	int CaptureImage();
	int StartImageCapture();
	void InitCamera();
	int AcquireImage();
	int StopImageAcquisition();
	int StartImageAcquisition();
	void YUV411toRGB(unsigned char* pBitmap);
	void SetVideoFrameRate(int rate);
	void SetVideoMode(int mode);
	int GetVideoMode();
	int GetVideoFrameRate();
	void WriteQuadlet(int address, int value);
	int ReadQuadlet(int address);
	void YUV422toRGB(unsigned char* pBitmap);
	void YUV444toRGB(unsigned char* pBitmap);
	void SetBrightness(int value);
	void SetAutoExposure(int value);
	void SetSharpness(int value);
	void SetWhiteBalance(int u, int v);
	void SetHue(int value);
	void SetSaturation(int value);
	void SetGamma(int value);
	void SetShutter(int value);
	void SetGain(int value);
	void ResetLink(bool root);
	void InquireControlRegisters();
	void StatusControlRegisters();
	int CheckLink();
	C1394Camera();
	virtual ~C1394Camera();

	C1394CameraControl m_controlBrightness;
	C1394CameraControl m_controlAutoExposure;
	C1394CameraControl m_controlSharpness;
	C1394CameraControl m_controlWhiteBalance;
	C1394CameraControl m_controlHue;
	C1394CameraControl m_controlSaturation;
	C1394CameraControl m_controlGamma;
	C1394CameraControl m_controlShutter;
	C1394CameraControl m_controlGain;
	C1394CameraControl m_controlZoom;
	C1394CameraControl m_controlFocus;
	C1394CameraControl m_controlIris;
	C1394CameraControlTrigger m_controlTrigger;
	C1394CameraControlSize m_controlSize;
	int m_width;
	int m_height;
	bool m_linkChecked;
	bool m_cameraInitialized;
	CString m_nameModel;
	CString m_nameVendor;
	unsigned char* m_pData;
	bool m_videoFlags[3][8][6];		// [format][mode][rate]

private:
	void DisableVideoMode(int format, int mode);
	void InquireVideoRates();
	void InquireVideoModes();
	void DisableVideoFormat(int format);
	void InquireVideoFormats();
	void UpdateParameters();
	void AllocateResources();
	void AllocateChannel();
	void AllocateBandwidth();
	void GetDeviceName();
	void StopListen();
	void Listen();
	void OneShot();
	void SetChannelSpeed();
	void Speed(int value);
	void StopVideoStream();
	void StartVideoStream();
	void InitResources();
	void FreeResources();

	int m_videoFrameRate;
	int m_videoMode;
	int m_videoFormat;
	int m_maxBytes;
	int m_maxBufferSize;
	int m_nBuffers;
	int m_nDescriptors;
	int m_node;
	unsigned int m_CSRoffset;
	bool m_allocateMemory;
	char* m_pName;
	DEVICE_DATA m_DeviceData;
	ASYNC_READ m_asyncRead;
	ASYNC_WRITE m_asyncWrite;
	ISOCH_ALLOCATE_BANDWIDTH m_bandwidth;
	ISOCH_ALLOCATE_CHANNEL m_channel;
	ISOCH_ALLOCATE_RESOURCES m_resource;
	PISOCH_ATTACH_BUFFERS m_pIsochAttachBuffers;
	ISOCH_GET_IMAGE_PARAMS m_isochGetImageParams;
	ISOCH_LISTEN m_listen;
	ISOCH_STOP m_stop;
	HWND m_hWnd;
	ULONG m_maxSpeed;
};

#endif // !defined(AFX_1394CAMERA_H__557833A0_777B_11D3_98EB_8250F54AA371__INCLUDED_)
