//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 1394CameraDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MY1394TYPE                  129
#define IDD_1394_PARTIAL_SCAN_DIALOG    130
#define IDD_1394_CAMERA_DIALOG          165
#define IDC_MONTHCALENDAR1              1000
#define IDC_EDIT_LEFT                   1001
#define IDC_SPIN_LEFT                   1002
#define IDC_EDIT_TOP                    1003
#define IDC_SPIN_TOP                    1004
#define IDC_EDIT_RIGHT                  1005
#define IDC_SPIN_RIGHT                  1006
#define IDC_EDIT_BOTTOM                 1007
#define IDC_SPIN_BOTTOM                 1008
#define IDC_SLIDER_SATURATION           1119
#define IDC_SLIDER_HUE                  1120
#define IDC_EDIT_HUE                    1126
#define IDC_EDIT_SATURATION             1127
#define IDC_SLIDER_SHUTTER              1243
#define IDC_EDIT_SHUTTER                1244
#define IDC_SLIDER_BRIGHTNESS           1245
#define IDC_EDIT_BRIGHTNESS             1246
#define IDC_SLIDER_GAIN                 1247
#define IDC_EDIT_GAIN                   1248
#define IDC_SLIDER_AUTOEXPOSURE         1249
#define IDC_EDIT_AUTOEXPOSURE           1250
#define IDC_SLIDER_WBALANCEU            1251
#define IDC_EDIT_WBALANCEU              1252
#define IDC_SLIDER_ZOOM                 1253
#define IDC_EDIT_ZOOM                   1254
#define IDC_SLIDER_SHARPNESS            1257
#define IDC_EDIT_SHARPNESS              1258
#define IDC_SLIDER_WBALANCEV            1259
#define IDC_EDIT_WBALANCEV              1260
#define IDC_COMBO_GAMMA                 1261
#define IDC_CHECK_SHUTTER               1262
#define IDC_CHECK_GAIN                  1263
#define IDC_CHECK_WBALANCE              1264
#define IDC_CHECK_AUTOEXPOSURE          1265
#define IDC_BUTTON_WB                   1266
#define IDC_BUTTON_WB_READ              1267
#define IDC_SLIDER_FOCUS                1268
#define IDC_EDIT_FOCUS                  1269
#define IDC_SLIDER_IRIS                 1270
#define IDC_EDIT_IRIS                   1271
#define IDC_CHECK_IRIS                  1272
#define ID_1394_MEASURE_FRAMERATE2      32771
#define ID_1394_640X480RGB              32772
#define ID_1394_INIT_CAMERA             32773
#define ID_1394_640X480MONO             32774
#define ID_1394_CAMERA_MODEL            32775
#define ID_1394_800X600YUV422           32776
#define ID_1394_SHOW_CAMERA2            32777
#define ID_1394_MAXIMUM_SPEED           32778
#define ID_1394_800X600RGB              32779
#define ID_1394_800X600MONO             32780
#define ID_1394_1024X768YUV422          32781
#define ID_1394_1024X768RGB             32782
#define ID_1394_1024X768MONO            32783
#define ID_1394_1280X960YUV422          32784
#define ID_1394_1280X960RGB             32785
#define ID_1394_1280X960MONO            32786
#define ID_1394_1600X1200YUV422         32787
#define ID_1394_1600X1200RGB            32788
#define ID_1394_1600X1200MONO           32789
#define ID_1394_2FPS                    32790
#define ID_1394_60FPS                   32791
#define ID_1394_CHECK_STREAM            32792
#define ID_1394_SAVE_IMAGE              32793
#define ID_1394_TRIGGER                 32794
#define ID_MODE_PARTIALSCAN             32795
#define ID_1394_PARTIALSCAN             32796
#define ID_CAMERA_SELECTCAMERA          32797
#define ID_CAMERA_SELECT_CAMERA         32798
#define ID_1394_SELECT_CAMERA           32798
#define ID_1394_CAMERA1                 32799
#define ID_1394_CAMERA2                 32800
#define ID_1394_CAMERA3                 32801
#define ID_1394_CAMERA4                 32802
#define ID_1394_CAMERA7                 32803
#define ID_1394_CAMERA6                 32804
#define ID_1394_CAMERA5                 32823
#define ID_1394_CAMERA8                 32824
#define ID_1394_CAMERA9                 32825
#define ID_1394_CHECK_LINK              32912
#define ID_1394_RESET_LINK              32913
#define ID_1394_CONTROL                 32916
#define ID_1394_SHOW_CAMERA             32917
#define ID_1394_STOP_CAMERA             32918
#define ID_1394_30FPS                   32919
#define ID_1394_15FPS                   32920
#define ID_1394_7FPS                    32921
#define ID_1394_4FPS                    32922
#define ID_1394_160X120YUV444           32923
#define ID_1394_320X240YUV422           32927
#define ID_1394_640X480YUV422           32928
#define ID_1394_640X480YUV411           32929
#define ID_1394_MEASURE_FRAMERATE1      32935

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32826
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
