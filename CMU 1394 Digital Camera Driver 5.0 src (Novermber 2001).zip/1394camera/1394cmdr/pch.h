/*++

Copyright (c) 1998	Microsoft Corporation

Module Name: 

    pch.h

Abstract


Author:

    Peter Binder (pbinder) 4/13/98

Revision History:
Date     Who       What
-------- --------- ------------------------------------------------------------
4/13/98  pbinder   birth
--*/

#include <wdm.h>
#include <1394.h>
#include "../inc/1394camapi.h"
#include "../inc/1394cmdr.h"
#include "debug.h"


