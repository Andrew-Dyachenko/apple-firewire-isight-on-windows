/*++

Copyright (c) 1998	Microsoft Corporation

Module Name: 

    pch.h

Abstract


Author:

    Peter Binder (pbinder) 4/08/98

Revision History:
Date     Who       What
-------- --------- ------------------------------------------------------------
4/08/98  pbinder   birth
--*/

#include <windows.h>
#include <winioctl.h>
#include <setupapi.h>
#include <dbt.h>
#include <stdlib.h>
#include "util.h"
#include "../inc/1394cmdr.h"
#include "../inc/1394camapi.h"
#include "local.h"
#include "debug.h"

#ifndef ULONG_PTR
#define ULONG_PTR unsigned long *
#endif
