//  1394CameraControlTrigger.cpp: implementation of the C1394CameraControlTrigger class.
//
//	Version 4.0
//
//	Copyright 5/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include "1394Camera.h"
#include "1394CameraControlTrigger.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C1394CameraControlTrigger::C1394CameraControlTrigger()
{
	m_polarity = false;
	m_statusPolarity = false;
	for (int i=0; i<4; i++)
		m_triggerMode[i] = false;
	m_statusMode = 0;;
}


C1394CameraControlTrigger::~C1394CameraControlTrigger()
{
}


void C1394CameraControlTrigger::Inquire()
{
/*	if(m_pCamera->GetVersion() < 0x000101)
		m_status = 0;
	else*/
		m_status = m_pCamera->ReadQuadlet(m_offsetInquiry);

	if (m_status & 0x80000000) 
		m_present = true; 
	else 
	{
		m_present = false;
		return;
	}

	if (m_status & 0x08000000) m_readout = true; 
	else m_readout = false;
	if (m_status & 0x04000000) m_onoff = true; 
	else m_onoff = false;
	if (m_status & 0x02000000) m_polarity = true; 
	else m_polarity = false;
	if (m_status & 0x00008000) m_triggerMode[0] = true; 
	else m_triggerMode[0] = false;
	if (m_status & 0x00004000) m_triggerMode[1] = true; 
	else m_triggerMode[1] = false;
	if (m_status & 0x00002000) m_triggerMode[2] = true; 
	else m_triggerMode[2] = false;
	if (m_status & 0x00001000) m_triggerMode[3] = true; 
	else m_triggerMode[3] = false;
}


void C1394CameraControlTrigger::Status()
{
	if(!m_present)
		return;
	m_status = m_pCamera->ReadQuadlet(m_offsetStatus);
	if (m_status & 0x02000000) m_statusOnOff = true; 
	else m_statusOnOff = false;
	if (m_status & 0x01000000) m_statusPolarity = true; 
	else m_statusPolarity = false;
	m_statusMode = m_status & 0x000f0000;
	m_value2 = m_status & 0x00fff000;
	m_value2 >>= 12;
	m_value1 = m_status & 0x00000fff;
	m_mode = m_status & 0xff000000;
}


void C1394CameraControlTrigger::SetPolarity(bool polarity)
{
	if(!m_present)
		return;
	if (polarity)	m_mode |= 0x01000000;
	else m_mode &= 0xfe000000;
	SetValues();
}


void C1394CameraControlTrigger::SetMode(int mode, int parameter)
{
	if(!m_present)
		return;
	m_statusMode = mode;
	m_value1 = parameter;
	SetValues();
}


void C1394CameraControlTrigger::SetValues()
{
	if(!m_present)
		return;
	m_status = m_statusMode;
	m_status <<= 16;
	m_status += m_value1;
	m_status = m_status | m_mode;
	m_pCamera->WriteQuadlet(m_offsetStatus, m_status);
}


void C1394CameraControlTrigger::TurnOn(bool on)
{
	if(!m_present)
		return;
	m_statusOnOff = on;
	if (on)	m_mode |= 0x02000000;
	else m_mode &= 0xfd000000;
	SetValues();
}
