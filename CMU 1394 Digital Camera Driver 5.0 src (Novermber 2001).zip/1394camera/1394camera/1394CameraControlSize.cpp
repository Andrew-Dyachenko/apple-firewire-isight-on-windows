//  1394CameraControlSize.cpp: implementation of the C1394CameraControlSize class.
//
//	Version 4.0
//
//	Copyright 5/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include "1394Camera.h"
#include "1394CameraControlSize.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C1394CameraControlSize::C1394CameraControlSize()
{
	m_maxH = 0;
	m_maxV = 0;
	m_unitH = 0;
	m_unitV = 0;
	m_top = 0;
	m_left = 0;
	m_width = 0;
	m_height = 0;
	m_colorCode = 0;
	for (int i=0; i<7; i++)
		m_colorCodes[i] = false;

	m_pixelsFrame = 0;
	m_bytesFrameHigh = 0;
	m_bytesFrameLow = 0;
	m_bytesPacketMin = 0;
	m_bytesPacketMax = 0;
	m_bytesPacket = 0;

	m_asyncRead.bRawMode = false;
	m_asyncRead.bGetGeneration = true;
	m_asyncRead.fulFlags = 0;
	m_asyncRead.DestinationAddress.IA_Destination_Offset.Off_High = 0xffff;
	m_asyncRead.nNumberOfBytesToRead = 4;
	m_asyncRead.nBlockSize = 0;

	m_asyncWrite.bRawMode = false;
	m_asyncWrite.bGetGeneration = true;
	m_asyncWrite.DestinationAddress.IA_Destination_Offset.Off_High = 0xffff;
	m_asyncWrite.nNumberOfBytesToWrite = 4;
	m_asyncWrite.nBlockSize = 0;
}


C1394CameraControlSize::~C1394CameraControlSize()
{
}

unsigned long C1394CameraControlSize::ReadQuadlet(unsigned long offset)
{
	unsigned long data,i;
	DWORD a;

/*	if(m_pCamera->GetVersion() < 0x000101)
		return 0;
*/
	m_asyncRead.DestinationAddress.IA_Destination_Offset.Off_Low = offset;
	a = AsyncRead(NULL, m_pCamera->m_pName, &m_asyncRead, false);
	if(a == 0)
	{
		data = 0;
		for(i=0; i<4; i++)
		{
			data <<= 8;
			data += m_asyncRead.Data[i];
		}
		return data;
	}
	return 0;
}

void C1394CameraControlSize::WriteQuadlet(unsigned long offset, unsigned long data)
{
	unsigned long i;
/*
	if(m_pCamera->GetVersion() < 0x000101)
		return;
*/
	for(i=3; i >= 0; i--)
	{
		m_asyncWrite.Data[i] = (unsigned char)(data & 255);
		data >>= 8;
	}

	m_asyncWrite.DestinationAddress.IA_Destination_Offset.Off_Low = offset;
	AsyncWrite(NULL, m_pCamera->m_pName, &m_asyncWrite, false);
}

void C1394CameraControlSize::Status()
{
	// size control present?
	if (!Supported())
		return;

	// mode supported?
	if (!ModeSupported(m_pCamera->m_videoMode))
		return;

	unsigned int status = m_pCamera->ReadQuadlet(0x2e0 + 4*m_pCamera->m_videoMode);

	m_offset = 4*status + 0xf0000000;

	// inquire features
	status = ReadQuadlet(m_offset + 0x00);
	m_maxV = status & 0xffff;
	m_maxH = status >> 16;
	status = ReadQuadlet(m_offset + 0x04);
	m_unitV = status & 0xffff;
	m_unitH = status >> 16;
	status = ReadQuadlet(m_offset + 0x08);
	m_top = status & 0xffff;
	m_left = status >> 16;
	status = ReadQuadlet(m_offset + 0x0c);
	m_height = status & 0xffff;
	m_width = status >> 16;
	status = ReadQuadlet(m_offset + 0x10);
	m_colorCode = status & 0x00ff;
	status = ReadQuadlet(m_offset + 0x14);
	unsigned int temp = 0x80000000;
	for (int i=0; i<7; i++)
	{
		if (status & temp) m_colorCodes[i] = true;
		else m_colorCodes[i] = false;
		temp >>= 1;
	}
	m_pixelsFrame = ReadQuadlet(m_offset + 0x34);
	m_bytesFrameHigh = ReadQuadlet(m_offset + 0x38);
	m_bytesFrameLow = ReadQuadlet(m_offset + 0x3c);
	status = ReadQuadlet(m_offset + 0x40);
	m_bytesPacketMax = status & 0xffff;
	m_bytesPacketMin = status >> 16;
	status = ReadQuadlet(m_offset + 0x44);
	m_bytesPacket = status >> 16;
}


void C1394CameraControlSize::SetPosition(int left, int top)
{
	m_left = left;
	m_top = top;
	unsigned int quadlet = left;
	quadlet <<= 16;
	quadlet += top;
	WriteQuadlet(m_offset + 0x08, quadlet);
	Update();
}


void C1394CameraControlSize::SetSize(int width, int height)
{
	m_width = width;
	m_height = height;
	unsigned int quadlet = width;
	quadlet <<= 16;
	quadlet += height;
	WriteQuadlet(m_offset + 0x0c, quadlet);
	Update();
}


void C1394CameraControlSize::SetColorCode(int code)
{
	m_colorCode = code;
	unsigned int quadlet = code;
	quadlet <<= 24;
	WriteQuadlet(m_offset + 0x10, quadlet);
	Update();
}

	
void C1394CameraControlSize::SetBytesPerPacket(int bytes)
{
	m_bytesPacket = bytes;
	unsigned int quadlet = bytes;
	quadlet <<= 16;
	WriteQuadlet(m_offset + 0x44, quadlet);
}


bool C1394CameraControlSize::ModeSupported(int mode)
{
	unsigned int status = ReadQuadlet(0x19c);
	unsigned int temp = 0x80000000;
	temp >>= mode;
	if (status & temp)
		return(true); 
	else
		return(false);
}


bool C1394CameraControlSize::Supported()
{
/*	if(m_pCamera->GetVersion() < 0x000101)
		return false;
*/
	unsigned int status = ReadQuadlet(0x100);
	if (status & 0x01000000)
		return(true); 
	else
		return(false);
}


void C1394CameraControlSize::Update()
{
	Status();
	SetBytesPerPacket(m_pCamera->m_controlSize.m_bytesPacketMax);
	m_pCamera->m_width = m_width;
	m_pCamera->m_height = m_height;
}
