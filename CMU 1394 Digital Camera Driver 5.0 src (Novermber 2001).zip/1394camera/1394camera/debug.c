/*++

Copyright (c) 1998  Microsoft Corporation

Module Name: 

    debug.c

Abstract


Authors:

    Peter Binder (pbinder) 4/08/98
	Christopher Baker (cbaker) 10/01

Revision History:
Date     Who       What
-------- --------- ------------------------------------------------------------
4/08/98  pbinder   birth
10/xx/01 cbaker    the old tracing mechanism was funky and required that the 
                   dll be built with debug symbols, so I made a new one.
--*/

#define _DEBUG_C
#include "pch.h"
#undef _DEBUG_C

void 
DbgPrt(
    IN HANDLE   hWnd,
    IN PUCHAR   lpszFormat,
    IN ... 
    )
{
    char    buf[1024] = "1394API: ";
    va_list ap;

    va_start(ap, lpszFormat);

    wvsprintf( &buf[9], lpszFormat, ap );
#ifdef _DEBUG
    OutputDebugStringA(buf);
#endif
/*    if (hWnd)
        WriteTextToEditControl(hWnd, buf);
*/
    va_end(ap);
}

/*
 * this is cbaker's tracing mechanism
 */

int DllTraceLevel = DLL_TRACE_ERROR;
void SetDllTraceLevel(int nlevel)
{
	DllTraceLevel = nlevel;
}

void DllTrace(int nlevel,const char *format, ...)
{

	if(nlevel > DllTraceLevel)
	{
		return;
	} else {
	    char buf[2048] = "1394Camera.dll: ";
		va_list ap;

		va_start(ap, format);
		wvsprintf(buf + 16, format, ap);
		OutputDebugStringA(buf);

		va_end(ap);
	}
}