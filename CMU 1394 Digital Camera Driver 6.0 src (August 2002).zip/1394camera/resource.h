//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 1394camera.rc
//
#define IDD_DEBUG                       102
#define IDD_CONTROL_PANE                103
#define IDR_CONTROL_MENU                104
#define IDD_ADVANCED_CONTROL            105
#define IDR_ICON1                       128
#define IDC_SLIDER_DLL                  1000
#define IDC_SLIDER_SYS                  1001
#define IDC_DLL_DESCRIPTION             1002
#define IDC_SYS_DESCRIPTION             1003
#define IDC_CHECK_DEFAULT               1004
#define IDC_SLIDER1                     1005
#define IDC_SLIDER2                     1006
#define IDC_SLIDER_FEEDBACK1            1007
#define IDC_SLIDER_FEEDBACK2            1008
#define IDC_TITLE                       1009
#define IDC_BUT_ADVANCED                1010
#define IDC_BUT_ONOFF                   1011
#define IDC_BUT_ONEPUSH                 1012
#define IDC_BUT_AUTO_MAN                1013
#define IDC_BUT_POLL                    1014
#define IDC_INQ_PRES                    1015
#define IDC_INQ_ONEPUSH                 1016
#define IDC_INQ_READ                    1017
#define IDC_INQ_ONOFF                   1018
#define IDC_INQ_AUTO                    1019
#define IDC_INQ_MANUAL                  1020
#define IDC_STA_PRES                    1021
#define IDC_STA_ONEPUSH                 1022
#define IDC_STA_ONOFF                   1023
#define IDC_STA_AUTO                    1024
#define IDC_STA_MANUAL                  1025
#define ID_FIRST_CONTROL_PANE           1026
#define ID_LAST_CONTROL_PANE            1090
#define IDC_EDIT_INQUIRY                1092
#define IDC_EDIT_STATUS                 1093
#define IDC_INQUIRY_BIT                 1094
#define ID_FILE_SAVEDEFAULTVIEW         40001
#define ID_FILE_LOADDEFAULTVIEW         40002
#define ID_FILE_CLOSETHISWINDOW         40003
#define ID_FILE_CLOSE                   40003
#define ID_VIEW_ALLCONTROLS             40004
#define ID_VIEW_CONTROL_START           40005
#define ID_VIEW_CONTROL_END             40069
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40070
#define _APS_NEXT_CONTROL_VALUE         1095
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
