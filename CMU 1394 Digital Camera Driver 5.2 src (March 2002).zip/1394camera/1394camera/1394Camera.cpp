//  1394Camera.cpp: implementation of the C1394Camera class.
//
//	Version 5.0 : 11/27/2001
//
//	Copyright 5/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  Copyright 11/2001
//
//  Christopher Baker
//  Robotics Institute
//  Carnegie Mellon University
//  Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//  10/2001 : Christopher Baker <cbaker@andrew.cmu.edu>
//  Made modifications and optimizations to take advantage
//  of the additional features provided by the new device driver
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <string.h>
#include <mmsystem.h>
#include <stdio.h>
#include "1394Camera.h"

extern "C" {
#include "pch.h"
}

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define ERRORBOX(str) MessageBox(m_hWnd,str,"1394Camera Error",MB_OK | MB_ICONERROR | MB_APPLMODAL)
//#define ERRORBOX(str) DllTrace(DLL_TRACE_ERROR,str)

int tableWidth[3][6] = {{160, 320, 640, 640, 640, 640},				// [format][mode]
						{800, 800, 800, 1024, 1024, 1024},
						{1280, 1280, 1280, 1600, 1600, 1600}};

int tableHeight[3][6] = {{120, 240, 480, 480, 480, 480},			// [format][mode]
						 {600, 600, 600, 768, 768, 768},
						 {960, 960, 960, 1200, 1200, 1200}};

int tableMaxBufferSize[3][6] = {{57600, 153600, 460800, 614400, 921600, 307200},		// [format][mode]
								{960000, 1440000, 480000, 1572864, 2359296, 786432},
								{2457600, 3686400, 1228800, 3840000, 5760000, 1920000}};

int tableMaxBytes[3][6][6] = {	{	{0, 0, 30, 60, 120, 0},					// format 0
/* [format][mode][rate]	*/			{0, 40, 80, 160, 320, 0},	
									{0, 120, 240, 480, 960, 0},	
									{0, 160, 320, 640, 1280, 0},	
									{0, 240, 480, 960, 1920, 0},	
									{0, 80, 160, 320, 640, 1280}},

								{	{0, 250, 500, 1000, 2000, 0},			// format 1
									{0, 0, 750, 1500, 0, 0},	
									{0, 0, 250, 500, 1000, 2000},	
									{192, 384, 768, 1536, 0, 0},	
									{288, 576, 1152, 0, 0, 0},	
									{96, 192, 384, 768, 1536, 0}},
	
								{	{320, 640, 1280, 0, 0, 0},					// format 2	
									{480, 960, 1920, 0, 0, 0},	
									{160, 320, 640, 1280, 0, 0},	
									{500, 1000, 2000, 0, 0, 0},	
									{750, 1500, 0, 0, 0, 0},	
									{250, 500, 1000, 2000, 0, 0}}};



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C1394Camera::C1394Camera(HWND hWnd)
{
	m_nBuffers = 2;
	m_nDescriptors = 1;
	
	m_pData = NULL;
	m_isochGetImageParams.pData = NULL;
	m_allocateMemory = true;
	m_pName = NULL;
	m_linkChecked = false;
	m_cameraInitialized = false;
	m_node = 0;
	m_hWnd = hWnd;

	m_videoMode = 1;
	m_videoFrameRate = 4;
	m_videoFormat = 1;
	memset(&m_spec,0,sizeof(CAMERA_SPECIFICATION));
	memset(&m_DeviceData,0,sizeof(DEVICE_DATA));

	m_controlBrightness.m_pCamera = this;
	m_controlAutoExposure.m_pCamera = this;
	m_controlSharpness.m_pCamera = this;
	m_controlWhiteBalance.m_pCamera = this;
	m_controlHue.m_pCamera = this;
	m_controlSaturation.m_pCamera = this;
	m_controlGamma.m_pCamera = this;
	m_controlShutter.m_pCamera = this;
	m_controlGain.m_pCamera = this;
	m_controlZoom.m_pCamera = this;
	m_controlFocus.m_pCamera = this;
	m_controlIris.m_pCamera = this;
	m_controlTrigger.m_pCamera = this;
	m_controlSize.m_pCamera = this;

	m_controlBrightness.m_offsetInquiry = 0x500;
	m_controlAutoExposure.m_offsetInquiry = 0x504;
	m_controlSharpness.m_offsetInquiry = 0x508;
	m_controlWhiteBalance.m_offsetInquiry = 0x50c;
	m_controlHue.m_offsetInquiry = 0x510;
	m_controlSaturation.m_offsetInquiry = 0x514;
	m_controlGamma.m_offsetInquiry = 0x518;
	m_controlShutter.m_offsetInquiry = 0x51c;
	m_controlGain.m_offsetInquiry = 0x520;
	m_controlZoom.m_offsetInquiry = 0x580;
	m_controlFocus.m_offsetInquiry = 0x528;
	m_controlIris.m_offsetInquiry = 0x524;
	m_controlTrigger.m_offsetInquiry = 0x530;

	m_controlBrightness.m_offsetStatus = 0x800;
	m_controlAutoExposure.m_offsetStatus = 0x804;
	m_controlSharpness.m_offsetStatus = 0x808;
	m_controlWhiteBalance.m_offsetStatus = 0x80c;
	m_controlHue.m_offsetStatus = 0x810;
	m_controlSaturation.m_offsetStatus = 0x814;
	m_controlGamma.m_offsetStatus = 0x818;
	m_controlShutter.m_offsetStatus = 0x81c;
	m_controlGain.m_offsetStatus = 0x820;
	m_controlZoom.m_offsetStatus = 0x880;
	m_controlFocus.m_offsetStatus = 0x828;
	m_controlIris.m_offsetStatus = 0x824;
	m_controlTrigger.m_offsetStatus = 0x830;
}


C1394Camera::~C1394Camera()
{}

int C1394Camera::CheckLink()
{
	if(GetNumberCameras() <= 0)
	{
		ERRORBOX("CheckLink Error: no cameras found");
		return 1;
	}

	SelectCamera(0);

	m_linkChecked = true;
	return 0;
}


void C1394Camera::Listen()
{
	DWORD a;
	m_listen.hResource = m_resource.hResource;
	m_listen.fulFlags = 0;
	m_listen.StartTime.CL_CycleOffset = 0;
	m_listen.StartTime.CL_CycleCount = 0;
	m_listen.StartTime.CL_SecondCount = 0;
	a = IsochListen(m_hWnd, m_pName, &m_listen);
	if (a != 0)
		ERRORBOX("Error on IsochListen");
}


void C1394Camera::StopListen()
{
	DWORD a;
	m_stop.hResource = m_resource.hResource;
	m_stop.fulFlags = 0;
	a = IsochStop(m_hWnd, m_pName, &m_stop);
	if (a != 0)
		ERRORBOX("Error on IsochStop");
}


void C1394Camera::OneShot()
{
	if(WriteRegisterUL(m_pName,0x61c,0x80000000) < 0)
		ERRORBOX("Problem Requesting Single Frame from Camera");
}


void C1394Camera::Speed(unsigned char value)
{
	unsigned long data = value;
	data <<= 24;
	
	if(WriteRegisterUL(m_pName,0x60c,data) < 0)
		ERRORBOX("Problem Setting Speed");
}


void C1394Camera::StartVideoStream()
{
	if(WriteRegisterUL(m_pName,0x614,0x80000000) < 0)
		ERRORBOX("Problem Starting Video Stream");
}


void C1394Camera::StopVideoStream()
{
	if(WriteRegisterUL(m_pName,0x614,0) < 0)
		ERRORBOX("Problem Stopping Video Stream");
}

unsigned long C1394Camera::GetVersion()
{
	return m_spec.ulVersion;
}

int C1394Camera::GetNumberCameras()
{
	return GetDeviceList(&m_DeviceData);
}


int C1394Camera::GetNode()
{
	return (m_node);
}


void C1394Camera::GetDeviceName()
{
	GetDeviceList(&m_DeviceData);
	m_pName = m_DeviceData.deviceList[0].DeviceName;
}


void C1394Camera::SelectCamera(int node)
{
	if(node < 0 || node >= (int) m_DeviceData.numDevices)
	{
		DllTrace(DLL_TRACE_ERROR,"SelectCamera: Camera %d out of range\n",node);
		return;
	}
	m_node = node;
	m_pName = m_DeviceData.deviceList[m_node].DeviceName;

	// check the software version
	memset(&m_spec,0,sizeof(CAMERA_SPECIFICATION));
	if(0 != GetCameraSpecification(m_pName,&m_spec))
		ERRORBOX("SelectCamera: Error getting Camera Specification");
	if(m_spec.ulSpecification != 0x00A02D)
	{
		char buf[256];
		sprintf(buf,"SelectCamera Warning: Specification (%06x) doesn't match 1394 Camera Specification (0x00A02D)",
				m_spec.ulSpecification);
		ERRORBOX(buf);
	}
	if (m_spec.ulVersion  < 0x000100 || m_spec.ulVersion > 0x000102)
	{
		char buf[256];
		sprintf(buf,"SelectCameraWarning: Version %06x is not valid",m_spec.ulVersion);
		ERRORBOX(buf);
	}
}


void C1394Camera::ResetLink(bool root)
{
	ULONG flags;
	GetDeviceName();
	if (root)
		flags = 2;
	else 
		flags = 0;
	if (BusReset(m_hWnd, m_pName, flags))
		ERRORBOX("Problem with Bus Reset");
}


void C1394Camera::InquireControlRegisters()
{
	m_controlBrightness.Inquire();
	m_controlAutoExposure.Inquire();
	m_controlSharpness.Inquire();
	m_controlWhiteBalance.Inquire();
	m_controlHue.Inquire();
	m_controlSaturation.Inquire();
	m_controlGamma.Inquire();
	m_controlShutter.Inquire();
	m_controlGain.Inquire();
	m_controlZoom.Inquire();
	m_controlFocus.Inquire();
	m_controlIris.Inquire();
	m_controlTrigger.Inquire();
}


void C1394Camera::StatusControlRegisters()
{
	m_controlBrightness.Status();
	m_controlAutoExposure.Status();
	m_controlSharpness.Status();
	m_controlWhiteBalance.Status();
	m_controlHue.Status();
	m_controlSaturation.Status();
	m_controlGamma.Status();
	m_controlShutter.Status();
	m_controlGain.Status();
	m_controlZoom.Status();
	m_controlFocus.Status();
	m_controlIris.Status();
	m_controlTrigger.Status();
	m_controlSize.Status();
}


// returns quadlet where bit 0 is the MSB
unsigned long C1394Camera::ReadQuadlet(unsigned long address)
{
	unsigned long data = 0;
	DWORD dwRet;
	if((dwRet = ReadRegisterUL(m_pName,address,&data)) != 0)
	{
		char buf[256];
		sprintf(buf,"Error %08x Reading from Register %08x\r\nIt may be possible to ignore this error and continue normally.",dwRet,address);
		switch(MessageBox(NULL,buf,"1394Camera Error",MB_ICONERROR | MB_ABORTRETRYIGNORE | MB_APPLMODAL))
		{
		case IDABORT:
			exit(1);
			break;
		case IDIGNORE:
			return 0;
			break;
		case IDRETRY:
			return ReadQuadlet(address);
			break;
		}
		//ERRORBOX(buf);
		// zero seems the safest value to return in case of error
		//return 0;
	}
	return data;
}


// writes quadlet where bit 0 is the MSB
void C1394Camera::WriteQuadlet(unsigned long address, unsigned long value)
{
	DWORD dwRet;
	if((dwRet = WriteRegisterUL(m_pName,address,value)) != 0)
	{
		char buf[256];
		sprintf(buf,"Error %08x Writing to Register %08x\r\nIt may be possible to ignore this error and continue normally.",dwRet,address);
		switch(MessageBox(NULL,buf,"1394Camera Error",MB_ICONERROR | MB_ABORTRETRYIGNORE | MB_APPLMODAL))
		{
		case IDABORT:
			exit(1);
			break;
		case IDIGNORE:
			return;
			break;
		case IDRETRY:
			WriteQuadlet(address,value);
			break;
		}
	}
}


void C1394Camera::SetBrightness(int value)
{
	if (m_controlBrightness.m_value1 == value)
		return;
	m_controlBrightness.m_value1 = value;
	m_controlBrightness.SetValues();
}


void C1394Camera::SetAutoExposure(int value)
{
	if (m_controlAutoExposure.m_value1 == value)
		return;
	m_controlAutoExposure.m_value1 = value;
	m_controlAutoExposure.SetValues();
}


void C1394Camera::SetGain(int value)
{
	if (m_controlGain.m_value1 == value)
		return;
	m_controlGain.m_value1 = value;
	m_controlGain.SetValues();
}


void C1394Camera::SetGamma(int value)
{
	if (m_controlGamma.m_value1 == value)
		return;
	m_controlGamma.m_value1 = value;
	m_controlGamma.SetValues();
}


void C1394Camera::SetHue(int value)
{
	if (m_controlHue.m_value1 == value)
		return;
	m_controlHue.m_value1 = value;
	m_controlHue.SetValues();
}


void C1394Camera::SetSaturation(int value)
{
	if (m_controlSaturation.m_value1 == value)
		return;
	m_controlSaturation.m_value1 = value;
	m_controlSaturation.SetValues();
}


void C1394Camera::SetSharpness(int value)
{
	if (m_controlSharpness.m_value1 == value)
		return;
	m_controlSharpness.m_value1 = value;
	m_controlSharpness.SetValues();
}


void C1394Camera::SetShutter(int value)
{
	if (m_controlShutter.m_value1 == value)
		return;
	m_controlShutter.m_value1 = value;
	m_controlShutter.SetValues();
}


void C1394Camera::SetZoom(int value)
{
	if (m_controlZoom.m_value1 == value)
		return;
	m_controlZoom.m_value1 = value;
	m_controlZoom.SetValues();
}


void C1394Camera::SetFocus(int value)
{
	if (m_controlFocus.m_value1 == value)
		return;
	m_controlFocus.m_value1 = value;
	m_controlFocus.SetValues();
}


void C1394Camera::SetIris(int value)
{
	if (m_controlIris.m_value1 == value)
		return;
	m_controlIris.m_value1 = value;
	m_controlIris.SetValues();
}


void C1394Camera::SetWhiteBalance(int u, int v)
{
	if ((m_controlWhiteBalance.m_value2 == u) && (m_controlWhiteBalance.m_value1 == v))
		return;
	m_controlWhiteBalance.m_value1 = v;
	m_controlWhiteBalance.m_value2 = u;
	m_controlWhiteBalance.SetValues();
}


void C1394Camera::SetVideoMode(int mode)
{
	if (!m_pName)
		GetDeviceName();

	m_videoMode = mode;

	if (m_videoFormat != 7)
	{
		if ((mode>=0)&&(mode<=5))
		{
			m_width = tableWidth[m_videoFormat][m_videoMode];
			m_height = tableHeight[m_videoFormat][m_videoMode];
			m_maxBufferSize = tableMaxBufferSize[m_videoFormat][m_videoMode];
		} else {
			char buf[256];
			sprintf(buf,"Video Mode %d not supported",mode);
			ERRORBOX(buf);
		}
	} else {
		m_width = m_controlSize.m_width;
		m_height = m_controlSize.m_height;
		m_maxBufferSize = m_width * m_height;		// only works for color code 0  (modify for other color codes)
		m_controlSize.Status();
	}

	mode <<= 29;
	WriteQuadlet(0x604, mode);
	UpdateParameters();
}


// 60fps = 5; 30fps = 4; 15fps = 3; 7.5fps = 2; 3.75fps = 1; 1.875fps = 0
void C1394Camera::SetVideoFrameRate(int rate)
{
	if (!m_pName)
		GetDeviceName();
	
	if ((rate>=0)&&(rate<=7))
	{
		m_videoFrameRate = rate;
		rate <<= 29;
		WriteQuadlet(0x600, rate);
		UpdateParameters();
	}
	else
		ERRORBOX("Problem: Video rate is not supported");
}


void C1394Camera::SetVideoFormat(int format)
{
	if (!m_pName)
		GetDeviceName();
	
	if ((format>=0)&&(format<=7))
	{
		m_videoFormat = format;
		format <<= 29;
		WriteQuadlet(0x608, format);
		UpdateParameters();
	}
	else
		ERRORBOX("Problem: Video format is not supported");

	if (format == 7)
		m_controlSize.Status();
}


// updates m_maxBytes based on video mode and frame rate

void C1394Camera::UpdateParameters()
{
	if (m_videoFormat != 7)
		m_maxBytes = tableMaxBytes[m_videoFormat][m_videoMode][m_videoFrameRate];
	else
		m_maxBytes = m_controlSize.m_bytesPacket;
}


int C1394Camera::GetVideoFrameRate()
{
	return (m_videoFrameRate);
}


int C1394Camera::GetVideoMode()
{
	return (m_videoMode);
}


int C1394Camera::GetVideoFormat()
{
	return (m_videoFormat);
}

// set channel and speed
void C1394Camera::SetChannelSpeed()
{
	int value = m_channel.Channel;			// set channel
	value <<= 4;
	value += (int) (m_maxSpeed/2);			// set speed
	value <<= 24;
	WriteQuadlet(0x60c, value);
}


void C1394Camera::FreeResources()
{
	if (IsochFreeResources(m_hWnd, m_pName, m_resource.hResource))
		ERRORBOX("Problem Freeing Resources");
	if (IsochFreeChannel(m_hWnd, m_pName, m_channel.Channel))
		ERRORBOX("Problem Freeing Channel");
	if (IsochFreeBandwidth(m_hWnd, m_pName, m_bandwidth.hBandwidth))
		ERRORBOX("Problem Freeing Bandwidth");
}

void C1394Camera::AllocateBandwidth()
{
	m_bandwidth.nMaxBytesPerFrameRequested = m_maxBytes;
	m_bandwidth.fulSpeed = m_maxSpeed;
	if (IsochAllocateBandwidth(m_hWnd, m_pName, &m_bandwidth))
		ERRORBOX("Problem Allocating Bandwidth");
}


void C1394Camera::AllocateChannel()
{
	m_channel.nRequestedChannel = m_node;
	if (IsochAllocateChannel(m_hWnd, m_pName, &m_channel))
		ERRORBOX("Problem Allocating Channel");
}


void C1394Camera::AllocateResources()
{
	m_resource.fulSpeed = m_maxSpeed;
	m_resource.fulFlags = RESOURCE_USED_IN_LISTENING|RESOURCE_STRIP_ADDITIONAL_QUADLETS; 				// Listen Mode
	m_resource.nChannel = m_channel.Channel;
	m_resource.nMaxBytesPerFrame = m_maxBytes;
	m_resource.nNumberOfBuffers = 10;
	m_resource.nMaxBufferSize = m_maxBufferSize;
	m_resource.nQuadletsToStrip = 1;
	if (IsochAllocateResources(m_hWnd, m_pName, &m_resource))
		ERRORBOX("Problem Allocating Resources");
}



void C1394Camera::InitResources()
{
	if (!m_pName)
		GetDeviceName();

	SetVideoFormat(m_videoFormat);
	SetVideoMode(m_videoMode);
	SetVideoFrameRate(m_videoFrameRate);

	AllocateBandwidth();
	AllocateChannel();
	AllocateResources();
	SetChannelSpeed();
		
	int ulBufferSize = sizeof(ISOCH_ATTACH_BUFFERS) +
		(m_maxBufferSize * m_nDescriptors) + (sizeof(RING3_ISOCH_DESCRIPTOR)*(m_nDescriptors-1));

	if (m_allocateMemory)
		m_pIsochAttachBuffers = (PISOCH_ATTACH_BUFFERS)GlobalAlloc(LPTR, ulBufferSize);
	else
		m_pIsochAttachBuffers = (PISOCH_ATTACH_BUFFERS)GlobalAlloc(LPTR, sizeof(ISOCH_ATTACH_BUFFERS));

	m_pIsochAttachBuffers->hResource = m_resource.hResource;
	m_pIsochAttachBuffers->nNumberOfDescriptors = m_nDescriptors;
	m_pIsochAttachBuffers->ulBufferSize = ulBufferSize;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].fulFlags = DESCRIPTOR_SYNCH_ON_SY;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].ulLength = m_maxBufferSize;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].nMaxBytesPerFrame = m_maxBytes;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].ulSynch = 1;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].ulTag = 0;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].CycleTime.CL_CycleOffset = 0;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].CycleTime.CL_CycleCount = 0;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].CycleTime.CL_SecondCount = 0;
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].bUseCallback = TRUE;		// or FALSE
	m_pIsochAttachBuffers->R3_IsochDescriptor[0].bAutoDetach = TRUE;
	m_isochGetImageParams.hWnd = m_hWnd;
	m_isochGetImageParams.szDeviceName = m_pName;
	if (m_allocateMemory)
		m_isochGetImageParams.bAutoAlloc = FALSE;
	else
		m_isochGetImageParams.bAutoAlloc = TRUE;
	m_isochGetImageParams.bAutoFill = FALSE;
	m_isochGetImageParams.pIsochAttachBuffers = m_pIsochAttachBuffers;
}

/***********************************************
 * old acquisition stuff here
 * these were essentially just class wrappers
 * for the functions in isochapi.c
 *
 * the new stuff is in 1394CamAcq.cpp
 ***********************************************
int C1394Camera::StartImageAcquisition()
{
	m_allocateMemory = false;
	if(!(m_videoFlags[m_videoFormat][m_videoMode][m_videoFrameRate]))
	{
		ERRORBOX("Current Video Settings are not Supported");
		return 0;
	}
	InitResources();
	StartVideoStream();
	a = IsochStartImageAcquisition(m_hWnd, &m_isochGetImageParams);
	return (a);
}


int C1394Camera::AcquireImage()
{
	a = IsochAcquireImage(m_hWnd, &m_isochGetImageParams);
	m_pData = m_isochGetImageParams.pData;
	return (a);
}


int C1394Camera::StopImageAcquisition()
{
	a = IsochStopImageAcquisition(m_hWnd, &m_isochGetImageParams);
	StopVideoStream();
	FreeResources();
	return (a);
}
*/

void C1394Camera::InitCamera()
{
	if(m_cameraInitialized)
		return;
	// reset state
	ResetCameraState(m_pName);

	/*
	 * the CSR stuff is maintained in the deviceExtension
	 * perhaps the Vendor and model should be as well
	 */

	// determine max speed
	GET_MAX_SPEED_BETWEEN_DEVICES maxSpeed;
	maxSpeed.fulFlags = 0;
	maxSpeed.ulNumberOfDestinations = 0;
	if (GetMaxSpeedBetweenDevices(m_hWnd, m_pName, &maxSpeed))
		ERRORBOX("Problem Getting Maximum Speed between Devices");
	ULONG maxSpeedNotLocal = maxSpeed.fulSpeed;
	maxSpeed.fulFlags = 1;
	if (GetMaxSpeedBetweenDevices(m_hWnd, m_pName, &maxSpeed))
		ERRORBOX("Problem Getting Maximum Speed between Devices");
	ULONG maxSpeedLocal = maxSpeed.fulSpeed;
	if (maxSpeedLocal < maxSpeedNotLocal) m_maxSpeed = maxSpeedLocal;
	else m_maxSpeed = maxSpeedNotLocal;
	
	GetModelName(m_pName,m_nameModel,MAX_NAME_LENGTH);
	GetVendorName(m_pName,m_nameVendor,MAX_NAME_LENGTH);

	// determine video formats/modes/rates
	InquireVideoFormats();
	InquireVideoModes();
	InquireVideoRates();

	m_cameraInitialized = true;
}

/***************************************************
 *  old capture stuff here
 *  once again, these were little more than wrappers
 *  for calls into isochapi.c
 *  new stuff in 1394CamCap.cpp
 ***************************************************

int C1394Camera::StartImageCapture()
{
	m_allocateMemory = true;
	if(!(m_videoFlags[m_videoFormat][m_videoMode][m_videoFrameRate]))
	{
		ERRORBOX("Current Video Settings are not Supported");
		return -1;
	}
	InitResources();
	StartVideoStream();
	a = IsochStartImageCapture(m_hWnd, &m_isochGetImageParams);
	StopVideoStream();
	return (a);
}


int C1394Camera::CaptureImage()
{
	a = IsochAttachBufferCapture(m_hWnd, &m_isochGetImageParams);
	StartVideoStream();
	a = IsochWaitImageCapture(m_hWnd, &m_isochGetImageParams);
	StopVideoStream();
	m_pData = m_isochGetImageParams.pData;
	return (a);
}


int C1394Camera::StopImageCapture()
{
	a = IsochStopImageCapture(m_hWnd, &m_isochGetImageParams);
	FreeResources();
	LocalFree(m_pIsochAttachBuffers);
	return (a);
}

*/

int C1394Camera::GetMaxSpeed()
{
	return (m_maxSpeed * 100);
}


void C1394Camera::InquireVideoFormats()
{
	int format, mode, rate, value;
	unsigned int temp;

	// initialize entire matrix to true
	for (format=0; format<3; format++)
		for (mode=0; mode<8; mode++)
			for (rate=0; rate<6; rate++)
				m_videoFlags[format][mode][rate] = true;
	
	// inquire video formats
	value = ReadQuadlet(0x100);
	temp = 0x80000000;
	for (format=0; format<3; format++)
	{
		if (!(value & temp)) DisableVideoFormat(format); 
		temp >>= 1;
	}	
}


void C1394Camera::DisableVideoFormat(int format)
{
	int mode, rate;

	for (mode=0; mode<8; mode++)
		for (rate=0; rate<6; rate++)
			m_videoFlags[format][mode][rate] = false;
}


void C1394Camera::InquireVideoModes()
{
	int format, mode, value;
	unsigned int temp;

	for (format=0; format<3; format++)
		if (m_videoFlags[format][0][0])
		{
			value = ReadQuadlet(0x180+format*4);
			temp = 0x80000000;
			for (mode=0; mode<8; mode++)
			{
				if (!(value & temp)) DisableVideoMode(format, mode); 
				temp >>= 1;
			}
		}
}


void C1394Camera::DisableVideoMode(int format, int mode)
{
	int rate;

	for (rate=0; rate<6; rate++)
		m_videoFlags[format][mode][rate] = false;
}


void C1394Camera::InquireVideoRates()
{
	int format, mode, rate, value;
	unsigned int temp;

	for (format=0; format<3; format++)
		for (mode=0; mode<8; mode++)
			if (m_videoFlags[format][mode][0])
			{
				value = ReadQuadlet(0x200+format*32+mode*4);
				temp = 0x80000000;
				for (rate=0; rate<6; rate++)
				{
					if (!(value & temp)) m_videoFlags[format][mode][rate] = false; 
					temp >>= 1;
				}
			}
}