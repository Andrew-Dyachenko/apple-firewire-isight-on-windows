///////////////////////////////////////////////////////////////////////////////
//
// 1394CamAcq.cpp
//
// source for C1394Camera::
//  - StartImageAcquisition
//  - AcquireImage
//  - StopImageAcquisition
//
// Based on the following functions originally by Iwan Ulrich and placed in isochapi.c:
//
//		IsochStartImageAcquisition
//		IsochAcquireImage
//		IsochStopImageAcquisition
//
//	Copyright 1/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  Copyright 11/2001
//
//  Christopher Baker
//  Robotics Institute
//  Carnegie Mellon University
//  Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//////////////////////////////////////////////////////////////////////
#include <windows.h>
#include <string.h>
#include <mmsystem.h>
#include <stdio.h>
#include "1394Camera.h"

extern "C" {
#include "pch.h"
}

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/*
 * new acquisition stuff
 * essentially moved the additions Iwan made to isochapi.c into the class
 * so that the global variables he referenced there would instead reference
 * members of the class and enable the use of multiple cameras from the same
 * app, provided you make an instance of the class for each one
 */

int C1394Camera::StartImageAcquisition()
{
	PISOCH_ATTACH_BUFFERS			pIsochAttachBuffers;
	PISOCH_GET_IMAGE_PARAMS			pIsochGetImageParams = &m_isochGetImageParams;
	RING3_ISOCH_DESCRIPTOR			R3_IsochDescriptor;
	PRING3_ISOCH_DESCRIPTOR 		pR3TempDescriptor;
	BOOL							b;	
	DWORD							dwRet, dwBytesRet;
	ISOCH_LISTEN					isochListen;
	OVERLAPPED						ListenOverlapped;						
	ULONG							i, j;

	if(!(m_videoFlags[m_videoFormat][m_videoMode][m_videoFrameRate]))
	{
		DllTrace(DLL_TRACE_ERROR,
				"StartImageAcquisition: Current Video Settings (%d,%d,%d) are not Supported",
				m_videoFormat,
				m_videoMode,
				m_videoFrameRate);
		return -1;
	}

	m_allocateMemory = false;
	InitResources();
	StartVideoStream();
	
	R3_IsochDescriptor = pIsochGetImageParams->pIsochAttachBuffers->R3_IsochDescriptor[0];
	
	// try to open the device
	m_hDeviceAcquisition = OpenDevice(pIsochGetImageParams->szDeviceName, TRUE);

	if(m_hDeviceAcquisition == INVALID_HANDLE_VALUE)
	{
		DllTrace(DLL_TRACE_ERROR,"StartImageAcquisition: error opening device (%s)\n",pIsochGetImageParams->szDeviceName);
		m_hDeviceAcquisition = NULL;
		return -1;
	}
	
	// device opened, so let's do loopback
	// lets calculate the buffer size
	m_acquisitionBufferSize = sizeof(ISOCH_ATTACH_BUFFERS) +
		(R3_IsochDescriptor.ulLength*pIsochGetImageParams->pIsochAttachBuffers->nNumberOfDescriptors) +
		(sizeof(RING3_ISOCH_DESCRIPTOR)*(pIsochGetImageParams->pIsochAttachBuffers->nNumberOfDescriptors-1));
	
	for (j=0; j<6; j++)
	{
		// init next pointers
		if (j < 4)
			m_acquisitionBuffer[j].pNextBuffer = &m_acquisitionBuffer[j+1];
		else
			m_acquisitionBuffer[j].pNextBuffer = NULL;		// last two buffers point to NULL

		m_acquisitionBuffer[j].index = j;

		// allocate memory
		pIsochAttachBuffers = (PISOCH_ATTACH_BUFFERS)LocalAlloc(LPTR, m_acquisitionBufferSize);
		if(pIsochAttachBuffers == NULL)
		{
			DllTrace(DLL_TRACE_ERROR,"StartImageAcquisition: Error Allocating Acquisition Buffer %d\n",j);
			for(j--;j>=0;j--)
			{
				CloseHandle(m_acquisitionBuffer[j].overLapped.hEvent);
				LocalFree(m_acquisitionBuffer[j].pIsochAttachBuffers);
			}
			return -1;
		}

		ZeroMemory(pIsochAttachBuffers, m_acquisitionBufferSize);
		*pIsochAttachBuffers = *pIsochGetImageParams->pIsochAttachBuffers;
		
		// setup each descriptor
		pR3TempDescriptor = &pIsochAttachBuffers->R3_IsochDescriptor[0];
		for (i=0; i < pIsochGetImageParams->pIsochAttachBuffers->nNumberOfDescriptors; i++) 
		{
			*pR3TempDescriptor = R3_IsochDescriptor;
			pR3TempDescriptor =
				(PRING3_ISOCH_DESCRIPTOR)((ULONG *)pR3TempDescriptor +
				pR3TempDescriptor->ulLength +
				sizeof(RING3_ISOCH_DESCRIPTOR));
		}

		// assign isoch buffer
		m_acquisitionBuffer[j].pIsochAttachBuffers = pIsochAttachBuffers;

		// create and reset event
		m_acquisitionBuffer[j].overLapped.hEvent = CreateEvent( NULL, TRUE, FALSE, NULL );
		ResetEvent(m_acquisitionBuffer[j].overLapped.hEvent);
	}

	// attach all but last buffer

	for(j=0; j<5; j++)
	{
		DeviceIoControl( m_hDeviceAcquisition,
				IOCTL_ISOCH_ATTACH_BUFFERS,
				m_acquisitionBuffer[j].pIsochAttachBuffers,
				m_acquisitionBufferSize,
				m_acquisitionBuffer[j].pIsochAttachBuffers,
				m_acquisitionBufferSize,
				&dwBytesRet,
				&m_acquisitionBuffer[j].overLapped
		);
	
		dwRet = GetLastError();
		if ((dwRet != ERROR_IO_PENDING) && (dwRet != ERROR_SUCCESS)) 
		{
			DllTrace(DLL_TRACE_ERROR,"StartImageAcquisition: Error %08x while Attaching Buffers\n",dwRet);
			return -1;
		}
	}

	// listen							
	ListenOverlapped.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
						
	isochListen.hResource = m_acquisitionBuffer[0].pIsochAttachBuffers->hResource;
	isochListen.fulFlags = 0;
	isochListen.StartTime.CL_SecondCount = 0;
	isochListen.StartTime.CL_CycleCount = 0;
	isochListen.StartTime.CL_CycleOffset = 0;
						
	b = DeviceIoControl( m_hDeviceAcquisition,
						IOCTL_ISOCH_LISTEN,
						&isochListen,
						sizeof(ISOCH_LISTEN),
						NULL,
						0,
						&dwBytesRet,
						&ListenOverlapped
						);

	if(!b)
	{
		dwRet = GetLastError();
		if(dwRet != ERROR_IO_PENDING)
		{
			DllTrace(DLL_TRACE_ERROR,"StartImageAcquisition: Error %08x on IOCTL_ISOCH_LISTEN\n");
			return -1;
		}
	}
				
	CloseHandle(ListenOverlapped.hEvent);		
				
	m_pFirstBuffer = &m_acquisitionBuffer[0];
	m_pLastBuffer = &m_acquisitionBuffer[6-2];
	m_pCurrentBuffer = &m_acquisitionBuffer[6-1];

	return 0;
}


int C1394Camera::AcquireImage()
{
	DWORD							dwRet, dwBytesRet;
	BOOL							ready;
	ACQUISITION_BUFFER				*pPreviousCurrentBuffer;
	ACQUISITION_BUFFER				*pPreviousFirstBuffer;
		
	// wait on an overlapped result for the first buffer
	// this will fall through unless you call it faster than the camera is DMA-ing images
		
	pPreviousCurrentBuffer = m_pCurrentBuffer;
	pPreviousFirstBuffer = m_pFirstBuffer;
	m_pCurrentBuffer = m_pFirstBuffer;

	// this used to be in a busy-wait loop with a slightly different function
	// the current version simply blocks if the first buffer is not ready yet.

	if(!GetOverlappedResult(m_hDeviceAcquisition, &m_pFirstBuffer->overLapped, &dwBytesRet, TRUE))
	{
		dwRet = GetLastError();
		DllTrace(DLL_TRACE_ERROR,"AcquireImage: Error %08x while Getting Overlapped Result\n",dwRet);
		return -1;
	}

	m_pCurrentBuffer = m_pFirstBuffer;
	m_pFirstBuffer = m_pFirstBuffer->pNextBuffer;

	// find last buffer that is still pending
	do
	{
		ready = GetOverlappedResult(m_hDeviceAcquisition, &m_pFirstBuffer->overLapped, &dwBytesRet, FALSE);
		if (ready)
		{
			m_pCurrentBuffer = m_pFirstBuffer;
			m_pFirstBuffer = m_pFirstBuffer->pNextBuffer;
		}
	}
	while ((ready) && (m_pFirstBuffer));

	// if all buffers are filled up, then our previous first buffer will again be the first buffer
	if (!m_pFirstBuffer)
		m_pFirstBuffer = pPreviousFirstBuffer;
	
	// reattach detached buffers
	while (pPreviousFirstBuffer != m_pCurrentBuffer)
	{
		// reset event and reattach buffer
		ResetEvent(pPreviousFirstBuffer->overLapped.hEvent);
		DeviceIoControl( m_hDeviceAcquisition,
						IOCTL_ISOCH_ATTACH_BUFFERS,
						pPreviousFirstBuffer->pIsochAttachBuffers,
						m_acquisitionBufferSize,
						pPreviousFirstBuffer->pIsochAttachBuffers,
						m_acquisitionBufferSize,
						&dwBytesRet,
						&pPreviousFirstBuffer->overLapped
						);
	
		dwRet = GetLastError();
		if ((dwRet != ERROR_IO_PENDING) && (dwRet != ERROR_SUCCESS)) 
		{
			DllTrace(DLL_TRACE_ERROR,"AcquireImage: Error %08x while Attaching Buffers\n",dwRet);
			return -1;
		}

		m_pLastBuffer->pNextBuffer = pPreviousFirstBuffer;
		m_pLastBuffer = pPreviousFirstBuffer;
		pPreviousFirstBuffer = pPreviousFirstBuffer->pNextBuffer;
		m_pLastBuffer->pNextBuffer = NULL;
	}

	// reattach current buffer
	ResetEvent(pPreviousCurrentBuffer->overLapped.hEvent);
	DeviceIoControl(m_hDeviceAcquisition,
					IOCTL_ISOCH_ATTACH_BUFFERS,
					pPreviousCurrentBuffer->pIsochAttachBuffers,
					m_acquisitionBufferSize,
					pPreviousCurrentBuffer->pIsochAttachBuffers,
					m_acquisitionBufferSize,
					&dwBytesRet,
					&pPreviousCurrentBuffer->overLapped
					);
	
	dwRet = GetLastError();
	if ((dwRet != ERROR_IO_PENDING) && (dwRet != ERROR_SUCCESS)) 
	{
		DllTrace(DLL_TRACE_ERROR,"AcquireImage: Error %08x while Attaching Buffers\n",dwRet);
		return -1;
	}

	m_pLastBuffer->pNextBuffer = pPreviousCurrentBuffer;
	m_pLastBuffer = pPreviousCurrentBuffer;
	m_pLastBuffer->pNextBuffer = NULL;
	
    m_pData = m_pCurrentBuffer->pIsochAttachBuffers->R3_IsochDescriptor[0].Data;
	return 0;
}


int C1394Camera::StopImageAcquisition()
{
	DWORD							dwBytesRet;
	ULONG							i;
	ISOCH_STOP						isochStop;
	OVERLAPPED						StopOverlapped;
	
	// wait for buffers to fill up
	do
	{
		GetOverlappedResult(m_hDeviceAcquisition, &m_pFirstBuffer->overLapped, &dwBytesRet, TRUE);
		m_pFirstBuffer = m_pFirstBuffer->pNextBuffer;
	}
	while (m_pFirstBuffer);
					
	// stop listening
	StopOverlapped.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	isochStop.hResource = m_acquisitionBuffer[0].pIsochAttachBuffers->hResource;
	isochStop.fulFlags = 0;
			
	DeviceIoControl(m_hDeviceAcquisition,
				IOCTL_ISOCH_STOP,
				&isochStop,
				sizeof(ISOCH_STOP),
				NULL,
				0,
				&dwBytesRet,
				&StopOverlapped
				);
			
	CloseHandle(StopOverlapped.hEvent);
		
	// free up all resources
	CloseHandle(m_hDeviceAcquisition);
	for (i=0; i<6; i++)
	{
		CloseHandle(m_acquisitionBuffer[i].overLapped.hEvent);
		if (m_acquisitionBuffer[i].pIsochAttachBuffers) 
			LocalFree(m_acquisitionBuffer[i].pIsochAttachBuffers);
	}

	m_hDeviceAcquisition = NULL;

	StopVideoStream();
	FreeResources();
	return 0;
}

