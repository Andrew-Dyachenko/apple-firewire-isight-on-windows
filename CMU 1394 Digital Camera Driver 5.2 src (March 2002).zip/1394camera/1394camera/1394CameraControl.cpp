//  1394CameraControl.cpp: implementation of the C1394CameraControl class.
//
//	Version 5.0 : 11/27/2001
//
//  Copyright 11/2001
//
//  Christopher Baker
//  Robotics Institute
//  Carnegie Mellon University
//  Pittsburgh, PA
//
//	Copyright 5/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include "1394Camera.h"
#include "1394CameraControl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C1394CameraControl::C1394CameraControl()
{
	m_value1 = 0;
	m_value2 = 0;
	m_mode = 0x80000000;
}


C1394CameraControl::~C1394CameraControl()
{
}


void C1394CameraControl::Inquire()
{
/*	if(m_offsetInquiry == 0x52C &&
		m_pCamera->GetVersion() < 0x000101)
	{
		// spec 1.04 does not support temperature
		m_present = m_onePush = m_readout = 
			m_onoff = m_auto = m_manual = false;
		m_min = m_max = 0;
	}*/
	m_status = m_pCamera->ReadQuadlet(m_offsetInquiry);
	if (m_status & 0x80000000) m_present = true; 
	else m_present = false;
	if (m_status & 0x10000000) m_onePush = true; 
	else m_onePush = false;
	if (m_status & 0x08000000) m_readout = true; 
	else m_readout = false;
	if (m_status & 0x04000000) m_onoff = true; 
	else m_onoff = false;
	if (m_status & 0x02000000) m_auto = true; 
	else m_auto = false;
	if (m_status & 0x01000000) m_manual = true; 
	else m_manual = false;
	m_min = m_status & 0x00fff000;
	m_min >>= 12;
	m_max = m_status & 0x00000fff;
}


void C1394CameraControl::Status()
{
/*	if(m_offsetInquiry == 0x52C &&
		m_pCamera->GetVersion() < 0x000101)
	{
		// spec 1.04 does not support temperature
		m_statusOnePush = m_statusOnOff = m_statusAutoManual = false;
		m_value1 = m_value2 = m_mode = 0;
	}*/
	m_status = m_pCamera->ReadQuadlet(m_offsetStatus);
	if (m_status & 0x04000000) m_statusOnePush = true; 
	else m_statusOnePush = false;
	if (m_status & 0x02000000) m_statusOnOff = true; 
	else m_statusOnOff = false;
	if (m_status & 0x01000000) m_statusAutoManual = true; 
	else m_statusAutoManual = false;
	m_value2 = m_status & 0x00fff000;
	m_value2 >>= 12;
	m_value1 = m_status & 0x00000fff;
	m_mode = m_status & 0xff000000;

}


// writes values 1 and 2 to camera
void C1394CameraControl::SetValues()
{
/*	if(m_offsetInquiry == 0x52C &&
		m_pCamera->GetVersion() < 0x000101)
		return;
*/
	m_status = m_value2;
	m_status <<= 12;
	m_status += m_value1;
	m_status = m_status | m_mode;
	m_pCamera->WriteQuadlet(m_offsetStatus, m_status);
}


// reads values 1 and 2 from camera
void C1394CameraControl::GetValues()
{
/*	if(m_offsetInquiry == 0x52C &&
		m_pCamera->GetVersion() < 0x000101)
		return;
*/
	m_status = m_pCamera->ReadQuadlet(m_offsetStatus);
	m_value2 = m_status & 0x00fff000;
	m_value2 >>= 12;
	m_value1 = m_status & 0x00000fff;
	m_mode = m_status & 0xff000000;
}


void C1394CameraControl::SetAutoMode(BOOL on)
{
	if (on)	m_mode |= 0x01000000;
	else m_mode &= 0xfe000000;
	SetValues();
}


void C1394CameraControl::SetOnePush()
{
	int oldMode = m_mode;
	m_mode |= 0x04000000;
	SetValues();
	m_mode = oldMode;
}


void C1394CameraControl::TurnOn(BOOL on)
{
	if (on)	m_mode |= 0x02000000;
	else m_mode &= 0xfd000000;
	SetValues();
}
