//  1394CamRGB.cpp: source for YUV to RGB conversion routines in C1394Camera
//
//	Version 5.0 : 10/29/2001
//
//	Copyright 5/2000 - 10/2001
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//  10/2001 : Christopher Baker <cbaker@andrew.cmu.edu>
//	used pointer tricks and integer math to make YUV to RGB conversion faster
//
//////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <string.h>
#include <mmsystem.h>
#include <stdio.h>
#include "1394Camera.h"


#define ERRORBOX(str) MessageBox(m_hWnd,str,"1394Camera Error",MB_OK)


void C1394Camera::getRGB(unsigned char *pBitmap)
{
	switch(m_videoFormat)
	{
		case 0:
			switch(m_videoMode)
			{
			case 0: 
				// 160x120 YUV444
				YUV444toRGB(pBitmap);
				return;
			case 1:
				// 320x240 YUV222
				YUV422toRGB(pBitmap);
				return;
			case 2:
				// 640x480 YUV411
				YUV411toRGB(pBitmap);
				return;
			case 3:
				// 640x480 YUV422
				YUV422toRGB(pBitmap);
				return;
			case 4:
				// 640x480 RGB
				memcpy(pBitmap,m_pData,640 * 480 * 3);
				return;
			case 5:
				// 640x480 MONO
				YtoRGB(pBitmap);
				return;
			default:
				ERRORBOX("getRGB: unknown video mode/format combination");
				return;
			}
		case 1:
			switch(m_videoMode)
			{
			case 0:
				// 800x600 YUV422
				YUV422toRGB(pBitmap);
				return;
			case 1:
				// 800x600 RGB
				memcpy(pBitmap,m_pData,800 * 600 * 3);
				return;
			case 2:
				// 800x600 MONO
				YtoRGB(pBitmap);
				return;
			case 3:
				// 1024x768 YUV422
				YUV422toRGB(pBitmap);
				return;
			case 4:
				// 1024x768 RGB
				memcpy(pBitmap,m_pData,1024 * 768 * 3);
				return;
			case 5:
				// 1024x768 MONO
				YtoRGB(pBitmap);
				return;
			default:
				ERRORBOX("getRGB: unknown video mode/format combination");
				return;
			}
		case 2:
			switch(m_videoMode)
			{
			case 0:
				// 1280x960 YUV422
				YUV422toRGB(pBitmap);
				return;
			case 1:
				// 1280x960 RGB
				memcpy(pBitmap,m_pData,1280 * 960 * 3);
				return;
			case 2:
				// 1280x960 MONO
				YtoRGB(pBitmap);
				return;
			case 3:
				// 1600x1200 YUV422
				YUV422toRGB(pBitmap);
				return;
			case 4:
				// 1600x1200 RGB
				memcpy(pBitmap,m_pData,1600 * 1200 * 3);
				return;
			case 5:
				// 1600x1200 MONO
				YtoRGB(pBitmap);
				return;
			default:
				ERRORBOX("getRGB: unknown video mode/format combination");
				return;
			}
		default:
			ERRORBOX("getRGB: unknown video mode/format combination");
			return;
	}
}

#define CLAMP_TO_UCHAR(a) (unsigned char)((a) < 0 ? 0 : ((a) > 255 ? 255 : (a)))

void C1394Camera::YUV444toRGB(unsigned char* pBitmap)
{
	long Y, U, V, deltaG;
	unsigned char *srcptr, *srcend, *destptr;

	srcptr = m_pData;
	srcend = srcptr + (m_width * m_height * 3);
	destptr = pBitmap;

	// data pattern: UYV
	// unroll it to 4 pixels/round

	while(srcptr < srcend)
	{
		U = (*srcptr++) - 128;
		Y = (*srcptr++);
		V = (*srcptr++) - 128;

		deltaG = (12727 * U + 33384 * V);
		deltaG += (deltaG > 0 ? 32768 : -32768);
		deltaG >>= 16;

		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		U = (*srcptr++) - 128;
		Y = (*srcptr++);
		V = (*srcptr++) - 128;

		deltaG = (12727 * U + 33384 * V);
		deltaG += (deltaG > 0 ? 32768 : -32768);
		deltaG >>= 16;

		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		U = (*srcptr++) - 128;
		Y = (*srcptr++);
		V = (*srcptr++) - 128;

		deltaG = (12727 * U + 33384 * V);
		deltaG += (deltaG > 0 ? 32768 : -32768);
		deltaG >>= 16;

		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		U = (*srcptr++) - 128;
		Y = (*srcptr++);
		V = (*srcptr++) - 128;

		deltaG = (12727 * U + 33384 * V);
		deltaG += (deltaG > 0 ? 32768 : -32768);
		deltaG >>= 16;

		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );
	}
}


void C1394Camera::YUV422toRGB(unsigned char *pBitmap)
{
	long Y, U, V, deltaG;
	unsigned char *srcptr, *srcend, *destptr;

	srcptr = m_pData;
	srcend = srcptr + ((m_width * m_height) << 1);
	destptr = pBitmap;

	// data pattern: UYVY

	while(srcptr < srcend)
	{
		U = *srcptr;
		U -= 128;
		V = *(srcptr+2);
		V -= 128;

		deltaG = (12727 * U + 33384 * V);
		deltaG += (deltaG > 0 ? 32768 : -32768);
		deltaG >>= 16;

		Y = *(srcptr + 1);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		Y = *(srcptr + 3);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		srcptr += 4;

		// twice in the same loop... just like halving the loop overhead

		U = (*srcptr) - 128;
		V = (*(srcptr+2)) - 128;

		deltaG = (12727 * U + 33384 * V);
		deltaG += (deltaG > 0 ? 32768 : -32768);
		deltaG >>= 16;

		Y = *(srcptr + 1);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		Y = *(srcptr + 3);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		srcptr += 4;

	}
}


void C1394Camera::YUV411toRGB(unsigned char *pBitmap)
{
	long Y, U, V, deltaG;
	unsigned char *srcptr, *srcend, *destptr;

	// data pattern: UYYVYY

	srcptr = m_pData;
	srcend = srcptr + ((m_width * m_height * 3) >> 1);
	destptr = pBitmap;

	while(srcptr < srcend)
	{
		U = (*srcptr) - 128;
		V = (*(srcptr+3)) - 128;

		deltaG = (12727 * U + 33384 * V);
		deltaG += (deltaG > 0 ? 32768 : -32768);
		deltaG >>= 16;

		Y = *(srcptr + 1);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		Y = *(srcptr + 2);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		Y = *(srcptr + 4);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		Y = *(srcptr + 5);
		*destptr++ = CLAMP_TO_UCHAR( Y + V );
		*destptr++ = CLAMP_TO_UCHAR( Y - deltaG );
		*destptr++ = CLAMP_TO_UCHAR( Y + U );

		srcptr += 6;
	}
}


void C1394Camera::YtoRGB(unsigned char *pBitmap)
{
	unsigned char *srcptr, *srcend, *destptr;

	srcptr = m_pData;
	srcend = srcptr + (m_width * m_height);
	destptr = pBitmap;

	// just Y's (monochrome)

	// unroll it to 4 per cycle

	while(srcptr < srcend)
	{
		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		srcptr++;

		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		srcptr++;

		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		srcptr++;

		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		*destptr++ = *srcptr;
		srcptr++;
	}
}

