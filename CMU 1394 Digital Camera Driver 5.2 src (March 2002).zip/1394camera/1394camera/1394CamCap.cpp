///////////////////////////////////////////////////////////////////////////////
//
// 1394CamCap.cpp
//
// source for C1394Camera::
//  - StartImageCapture
//  - CaptureImage
//  - StopImageCapture
//
// Based on the following functions originally by Iwan Ulrich from isochapi.c:
//
//		IsochStartImageCapture
//		IsochAttachBufferCapture
//		IsochWaitImageCapture
//		IsochStopImageCapture
//
//	Copyright 1/2000
// 
//	Iwan Ulrich
//	Robotics Institute
//	Carnegie Mellon University
//	Pittsburgh, PA
//
//  Copyright 11/2001
//
//  Christopher Baker
//  Robotics Institute
//  Carnegie Mellon University
//  Pittsburgh, PA
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <string.h>
#include <mmsystem.h>
#include <stdio.h>
#include "1394Camera.h"

extern "C" {
#include "pch.h"
}

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

int C1394Camera::StartImageCapture()
{
	PISOCH_ATTACH_BUFFERS			pIsochAttachBuffers;
	ISOCH_LISTEN					isochListen;
	DWORD							dwBytesRet, dwRet;
	OVERLAPPED						ListenOverlapped;						
		
	if(!(m_videoFlags[m_videoFormat][m_videoMode][m_videoFrameRate]))
	{
		DllTrace(DLL_TRACE_ERROR,
				"StartImageCapture: Current Video Settings (%d,%d,%d) are not Supported",
				m_videoFormat,
				m_videoMode,
				m_videoFrameRate);
		return -1;
	}

	m_allocateMemory = true;
	InitResources();
	StartVideoStream();
	
	if(m_hDeviceCapture != NULL)
		return 0;

	// try to open the device
	m_hDeviceCapture = OpenDevice(m_pName, TRUE);

	if(m_hDeviceCapture == INVALID_HANDLE_VALUE)
	{
		DllTrace(DLL_TRACE_ERROR,"StartImageCapture: error opening device (%s)\n",m_pName);
		StopVideoStream();
		FreeResources();
		LocalFree(m_isochGetImageParams.pIsochAttachBuffers);
		m_hDeviceCapture = NULL;
		return -1;
	}
	
	// device opened, so let's attach a buffer

	// we have already received an allocated buffer, let's just map it into
	// our attach struct and pass it down.
	pIsochAttachBuffers = m_isochGetImageParams.pIsochAttachBuffers;
	m_captureBufferSize = pIsochAttachBuffers->ulBufferSize;

	m_captureOverlapped.hEvent = CreateEvent( NULL, TRUE, FALSE, NULL );
	ResetEvent(m_captureOverlapped.hEvent);
		
	// attach buffer
	DeviceIoControl( m_hDeviceCapture,
				IOCTL_ISOCH_ATTACH_BUFFERS,
				pIsochAttachBuffers,
				m_captureBufferSize,
				pIsochAttachBuffers,
				m_captureBufferSize,
				&dwBytesRet,
				&m_captureOverlapped
				);

	dwRet = GetLastError();
		
	if ((dwRet != ERROR_IO_PENDING) && (dwRet != ERROR_SUCCESS)) 
	{
		DllTrace(DLL_TRACE_ERROR,"StartImageCapture: Error %08x on IOCTL_ISOCH_ATTACH_BUFFERS\n");
		StopVideoStream();
		return -1;
	}

	// start listenening							
	ListenOverlapped.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	isochListen.hResource = pIsochAttachBuffers->hResource;
	isochListen.fulFlags = 0;
	isochListen.StartTime.CL_SecondCount = 0;
	isochListen.StartTime.CL_CycleCount = 0;
	isochListen.StartTime.CL_CycleOffset = 0;

	DeviceIoControl( m_hDeviceCapture,
				IOCTL_ISOCH_LISTEN,
				&isochListen,
				sizeof(ISOCH_LISTEN),
				NULL,
				0,
				&dwBytesRet,
				&ListenOverlapped
				);
			
	CloseHandle(ListenOverlapped.hEvent);

	// wait for buffer to fill up
	if (!GetOverlappedResult(m_hDeviceCapture, &m_captureOverlapped, &dwBytesRet, TRUE)) 
	{	
		// getoverlappedresult failed, lets find out why...
		dwRet = GetLastError();
		DllTrace(DLL_TRACE_ERROR,"StartImageCapture: Error %08x on GetOverlappedResult\n");
		StopVideoStream();
		return -1;
	}
			
	m_isochGetImageParams.pData = (pIsochAttachBuffers->R3_IsochDescriptor[0].Data);

	StopVideoStream();
	return 0;
}


int C1394Camera::CaptureImage()
{
	PISOCH_ATTACH_BUFFERS			pIsochAttachBuffers;
	DWORD							dwRet, dwBytesRet;

	if(!m_hDeviceCapture)
		// not capturing
		return -1;
		
	pIsochAttachBuffers = m_isochGetImageParams.pIsochAttachBuffers;
		
	m_captureOverlapped.hEvent = CreateEvent( NULL, TRUE, FALSE, NULL );
	ResetEvent(m_captureOverlapped.hEvent);
			
	// attach buffer
	DeviceIoControl( m_hDeviceCapture,
				IOCTL_ISOCH_ATTACH_BUFFERS,
				pIsochAttachBuffers,
				m_captureBufferSize,
				pIsochAttachBuffers,
				m_captureBufferSize,
				&dwBytesRet,
				&m_captureOverlapped
				);
			
	dwRet = GetLastError();
			
	if ((dwRet != ERROR_IO_PENDING) && (dwRet != ERROR_SUCCESS)) 
	{
		DllTrace(DLL_TRACE_ERROR,"CaptureImage: Error %08x on IOCTL_ISOCH_ATTACH_BUFFERS\n");
		StopVideoStream();
		return -1;
	}

	StartVideoStream();

	// wait for buffer to fill up with image
	if (!GetOverlappedResult(m_hDeviceCapture, &m_captureOverlapped, &dwBytesRet, TRUE)) 
	{	
		// getoverlappedresult failed, lets find out why...
		dwRet = GetLastError();
		DllTrace(DLL_TRACE_ERROR,"CaptureImage: Error %08x on GetOverlappedResult\n");
		StopVideoStream();
		return -1;
	}
				
	m_isochGetImageParams.pData = m_isochGetImageParams.pIsochAttachBuffers->R3_IsochDescriptor[0].Data;

	StopVideoStream();

	m_pData = m_isochGetImageParams.pData;
	return 0;
}


int C1394Camera::StopImageCapture()
{
	DWORD							dwBytesRet;
	ISOCH_STOP						isochStop;
	OVERLAPPED						StopOverlapped;

	if(m_hDeviceCapture == NULL)
		// already not capturing
		return 0;
			
	// stop listening
	StopOverlapped.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	isochStop.hResource = m_isochGetImageParams.pIsochAttachBuffers->hResource;
	isochStop.fulFlags = 0;
			
	DeviceIoControl( m_hDeviceCapture,
				IOCTL_ISOCH_STOP,
				&isochStop,
				sizeof(ISOCH_STOP),
				NULL,
				0,
				&dwBytesRet,
				&StopOverlapped
				);
			
	CloseHandle(StopOverlapped.hEvent);

	// free up all resources
	CloseHandle(m_hDeviceCapture);
	m_hDeviceCapture = NULL;
	CloseHandle(m_captureOverlapped.hEvent);

	FreeResources();
	LocalFree(m_pIsochAttachBuffers);
	return 0;
}
