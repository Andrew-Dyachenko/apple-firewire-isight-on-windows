/*++

Copyright (c) 1998 Microsoft Corporation

Module Name:

    1394cmdr.c

Abstract:

Author:

    Peter Binder (pbinder) 4/13/98
	Christopher Baker (cbaker) 10/01

Revision History:
Date     Who       What
-------- --------- ------------------------------------------------------------
4/13/98  pbinder   taken from original 1394diag...
10/xx/01 cbaker    moved the lookup of device name, vendor, and CSR offset to this level
                   many functions were added to facilitate this
--*/

#define _1394CMDR_C
#include "pch.h"
#undef _1394CMDR_C

#if DBG

unsigned char t1394CmdrDebugLevel = TL_WARNING;
unsigned char t1394CmdrTrapLevel = FALSE;

#endif

/*
 * GetState
 *
 * The bottom half of the state stub... as yet unused
 */

NTSTATUS
t1394Cmdr_GetState(
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp,
	OUT PLONG			pState
    )
{

	PDEVICE_EXTENSION deviceExtension = DeviceObject->DeviceExtension;
	*pState = deviceExtension->Status;
	return STATUS_SUCCESS;
}

/*
 * GetStuff
 *
 * queries the camera to figure out the CSR offset, model name, and vendor name
 * all this info is stored for the lifetime of the driver instance in the device extension
 */

NTSTATUS
t1394Cmdr_GetStuff(
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
	ULONG offset,unit_directory_offset,unit_dependent_directory_offset,
				vendor_name_offset,model_name_offset,i;
	UCHAR bytes[4];
	PDEVICE_EXTENSION deviceExtension = DeviceObject->DeviceExtension;
	PCAMERA_STATE cameraState = &(deviceExtension->CameraState);
	NTSTATUS ntStatus;

	// determine Unit Directory Address
	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,0xf0000424,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(UDA) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	offset = 0;
	for(i=1; i<4; i++)
	{
		offset <<= 8;
		offset += bytes[i];
	}
	//offset = bytes[1]*65536 + bytes[2]*256 + bytes[3];
	unit_directory_offset = 0xf0000424 + offset*4;

	// read the specification ID (should be 0x00A02D)

	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,unit_directory_offset + 0x4,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(spec_ID) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	deviceExtension->unit_spec_ID = 0;
	for(i=1; i<4; i++)
	{
		deviceExtension->unit_spec_ID <<= 8;
		deviceExtension->unit_spec_ID += bytes[i];
	}

	// read the software version (0x000101 => 1.20, 0x00100 => 1.04)

	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,unit_directory_offset + 0x8,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(sw_version) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	deviceExtension->unit_sw_version = 0;
	for(i=1; i<4; i++)
	{
		deviceExtension->unit_sw_version <<= 8;
		deviceExtension->unit_sw_version += bytes[i];
	}

	// determine Unit Dependent Directory Address
	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,unit_directory_offset + 0xc,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(UDDA) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	offset = bytes[1]*65536 + bytes[2]*256 + bytes[3];
	unit_dependent_directory_offset = unit_directory_offset + 0xc + offset*4;

	// determine CSR offset
	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,unit_dependent_directory_offset + 4,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(CSR offset) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	offset = bytes[1]*65536 + bytes[2]*256 + bytes[3];
	deviceExtension->CSR_offset = 0xf0000000 + offset*4;
	// determine vendor name offset
	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,unit_dependent_directory_offset + 8,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(vendor name offset) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	offset = bytes[1]*65536 + bytes[2]*256 + bytes[3];

	DbgPrint("1394CMDR: GetStuff: vendor offset = 0x%06x\n",offset);

	vendor_name_offset = unit_dependent_directory_offset + 8 + offset*4;

	// determine model name offset
	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,unit_dependent_directory_offset + 12,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(model name offset) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	offset = bytes[1]*65536 + bytes[2]*256 + bytes[3];
	DbgPrint("1394CMDR: GetStuff: model offset = 0x%06x\n",offset);
	model_name_offset = unit_dependent_directory_offset + 12 + offset*4;

	// determine model name
	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,model_name_offset,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(model name length) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	deviceExtension->ModelNameLength = bytes[0] * 256 + bytes[1] - 2;
	if((deviceExtension->ModelNameLength * 4) > MAX_NAME_LENGTH)
		deviceExtension->ModelNameLength = MAX_NAME_LENGTH / 4;

	for (i=0; i<deviceExtension->ModelNameLength; i++)
	{
		ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,model_name_offset + 0xc + i * 4,bytes);
		if (!NT_SUCCESS(ntStatus))
		{	
			DbgPrint("Error on ReadRegister(model name (%d)) = 0x%x\n", i, ntStatus);
			return STATUS_UNSUCCESSFUL;
		}
		RtlCopyMemory(deviceExtension->ModelName + (4 * i),bytes,4);
	}

	// determine vendor name
	ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,vendor_name_offset,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        DbgPrint("Error on ReadRegister(vendor name length) = 0x%x\n", ntStatus);
		return STATUS_UNSUCCESSFUL;
	}
	deviceExtension->VendorNameLength = bytes[0] * 256 + bytes[1] - 2;
	if((deviceExtension->VendorNameLength * 4) > MAX_NAME_LENGTH)
		deviceExtension->VendorNameLength = MAX_NAME_LENGTH / 4;

	for (i=0; i<deviceExtension->VendorNameLength; i++)
	{
		ntStatus = t1394Cmdr_ReadRegister(DeviceObject,Irp,vendor_name_offset + 0xc + i * 4,bytes);
		if (!NT_SUCCESS(ntStatus))
		{	
			DbgPrint("Error on ReadRegister(vendor name (%d)) = 0x%x\n", i, ntStatus);
			return STATUS_UNSUCCESSFUL;
		}
		RtlCopyMemory(deviceExtension->ModelName + (4 * i),bytes,4);
	}
	return STATUS_SUCCESS;
}

/*
 * ResetState
 *
 * Clears out any Isoch Channel, Bandwidth, or Resources
 * Detaches and frees any DMA buffers
 * Tells the Camera to Stop streaming data
 */
	

NTSTATUS
t1394Cmdr_ResetState(
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
	ULONG CSR_offset;
	PDEVICE_EXTENSION deviceExtension = DeviceObject->DeviceExtension;
	PCAMERA_STATE cameraState = &(deviceExtension->CameraState);
	NTSTATUS ntStatus;
	UCHAR bytes[4];

	CSR_offset = deviceExtension->CSR_offset;

	if(CSR_offset == 0xffffffff)
	{
		DbgPrint("1394CMDR: no CSR_offset available... what the hell's going on?\n");
		return STATUS_UNSUCCESSFUL;
	}

	/* tell the camera to stop streaming */

	RtlZeroMemory(bytes,4);
	ntStatus = t1394Cmdr_WriteRegister(DeviceObject,Irp,deviceExtension->CSR_offset + 0x614,bytes);
    if (!NT_SUCCESS(ntStatus))
	{
        TRACE(TL_ERROR, ("1394CMDR: Write Error = 0x%x\n", ntStatus));
		goto Exit_ResetState;
	}

	// send some isoch stop

	if(cameraState->hIsochResource != NULL)
	{
		ntStatus = t1394Cmdr_IsochStop(DeviceObject, Irp, cameraState->hIsochResource, 0);
		if (!NT_SUCCESS(ntStatus))
		{
			TRACE(TL_ERROR, ("Error on IsochStop = 0x%x\n", ntStatus));
			goto Exit_ResetState;
		}
	}

	// deallocate any attached buffers

	while (TRUE) {
		KIRQL               Irql;

		KeAcquireSpinLock(&deviceExtension->IsochSpinLock, &Irql);

		if (!IsListEmpty(&deviceExtension->IsochDetachData)) {

			PISOCH_DETACH_DATA      IsochDetachData;

			IsochDetachData = (PISOCH_DETACH_DATA)RemoveHeadList(&deviceExtension->IsochDetachData);

			TRACE(TL_TRACE, ("Surprise Removal: IsochDetachData = 0x%x\n", IsochDetachData));

			KeCancelTimer(&IsochDetachData->Timer);

			// clear the tag...
			IsochDetachData->Tag = 0;

			KeReleaseSpinLock(&deviceExtension->IsochSpinLock, Irql);

			TRACE(TL_TRACE, ("Surprise Removal: IsochDetachData->Irp = 0x%x\n", IsochDetachData->Irp));

			// need to save the status of the attach
			// we'll clean up in the same spot for success's and timeout's
			IsochDetachData->AttachStatus = STATUS_SUCCESS;

			// detach no matter what...
			IsochDetachData->bDetach = TRUE;

			t1394Cmdr_IsochCleanup(IsochDetachData);
		}
		else {

			KeReleaseSpinLock(&deviceExtension->IsochSpinLock, Irql);
			break;
		}
	}

	
	if(cameraState->hIsochBandwidth != NULL)
	{
		DbgPrint("1394CMDR:\t0x%08x : bandwidth",cameraState->hIsochBandwidth);
		ntStatus = t1394Cmdr_IsochFreeBandwidth(DeviceObject,Irp,cameraState->hIsochBandwidth);
	    if (!NT_SUCCESS(ntStatus))
		{
	        TRACE(TL_ERROR, ("IsochFreeBandwidth Failed = 0x%x\n", ntStatus));
			goto Exit_ResetState;
		}
	}

	if(cameraState->hIsochResource != NULL)
	{
		DbgPrint("1394CMDR:\t0x%08x : Resource",cameraState->hIsochResource);
		ntStatus = t1394Cmdr_IsochFreeResources(DeviceObject,Irp,cameraState->hIsochResource);
	    if (!NT_SUCCESS(ntStatus))
		{
	        TRACE(TL_ERROR, ("IsochFreeResources Failed = 0x%x\n", ntStatus));
			goto Exit_ResetState;
		}
	}

	if(cameraState->IsochChannel != -1)
	{
		DbgPrint("1394CMDR:\t  %8d  : Channel",cameraState->IsochChannel);
		ntStatus = t1394Cmdr_IsochFreeChannel(DeviceObject,Irp,cameraState->IsochChannel);
	    if (!NT_SUCCESS(ntStatus))
		{
	        TRACE(TL_ERROR, ("IsochFreeChannel Failed = 0x%x\n", ntStatus));
			goto Exit_ResetState;
		}
	}

Exit_ResetState:

	if(!NT_SUCCESS(ntStatus))
		DbgPrint("1394CMDR: Generalized funk error: it is recommended that you reboot the camera\n");
 
	ntStatus = STATUS_SUCCESS;

	return ntStatus;
}

/*
 * The tracelevel lower half stub
 */

NTSTATUS
SetCmdrTraceLevel( 
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp,
	IN LONG			dwLevel
    )
{
	PDEVICE_EXTENSION deviceExtension = DeviceObject->DeviceExtension;
	deviceExtension->TraceLevel = dwLevel;
	return STATUS_SUCCESS;
}

/*
 * DriverEntry
 *
 * just like any others
 */

NTSTATUS
DriverEntry(
    IN PDRIVER_OBJECT   DriverObject,
    IN PUNICODE_STRING  RegistryPath
    )
{
    NTSTATUS    ntStatus = STATUS_SUCCESS;

    ENTER("DriverEntry");

    DriverObject->MajorFunction[IRP_MJ_CREATE]          = t1394Cmdr_Create;
    DriverObject->MajorFunction[IRP_MJ_CLOSE]           = t1394Cmdr_Close;
    DriverObject->MajorFunction[IRP_MJ_PNP]             = t1394Cmdr_Pnp;
    DriverObject->MajorFunction[IRP_MJ_POWER]           = t1394Cmdr_Power;
//    DriverObject->MajorFunction[IRP_MJ_READ]            = t1394Cmdr_AsyncRead;
//    DriverObject->MajorFunction[IRP_MJ_WRITE]           = t1394Cmdr_Write;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]  = t1394Cmdr_IoControl;
//    DriverObject->MajorFunction[IRP_MJ_SYSTEM_CONTROL]  = OhciCmdr_SystemControl;
    DriverObject->DriverExtension->AddDevice            = t1394Cmdr_PnpAddDevice;
//    DriverObject->DriverUnload                          = OhciCmdr_Unload;

    EXIT("DriverEntry", ntStatus);
    return(ntStatus);
} // DriverEntry

/*
 * Create
 *
 * Called as a result of a handle being opened
 *
 * If its the first handle, I call GetStuff to figure out
 * the persistent stuff about the camera
 */

NTSTATUS
t1394Cmdr_Create(
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    NTSTATUS    ntStatus = STATUS_SUCCESS;
    PDEVICE_EXTENSION   deviceExtension = DeviceObject->DeviceExtension;
	PANSI_STRING pstr;
	char *t;

    ENTER("t1394Cmdr_Create");

	if(deviceExtension->CSR_offset == 0xffffffff)
	{
		DbgPrint("1394CMDR: oooh, my first handle... lemme figure out the particulars\n");
		if(STATUS_SUCCESS != t1394Cmdr_GetStuff(DeviceObject,Irp))
			DbgPrint("1394CMDR: error getting stuff");
		else 
		{
			DbgPrint("1394CMDR: my offset is: 0x%08x\n",deviceExtension->CSR_offset);
			DbgPrint("1394CMDR: my specification ID is 0x%06x\n",deviceExtension->unit_spec_ID);
			if(deviceExtension->unit_spec_ID != 0x00A02D)
				DbgPrint("1394CMDR: WARNING! this does not appear to conform with the 1394 DCS\n");
			switch(deviceExtension->unit_sw_version)
			{
			case 0x000100:
				t = "1.04";
				break;
			case 0x000101:
				t = "1.20";
				break;
			case 0x000102:
				t = "1.30";
				break;
			default:
				t = "unknown";
			}
			DbgPrint("1394CMDR: my software version is 0x%06x (%s)\n",
					deviceExtension->unit_sw_version, t);
					
			DbgPrint("1394CMDR: my name is: %s (len = %d)\n",
				      deviceExtension->ModelName,
					  deviceExtension->ModelNameLength);

			DbgPrint("1394CMDR: my vendor is: %s (len = %d)\n",
				      deviceExtension->VendorName,
					  deviceExtension->VendorNameLength);
		}
	}

	pstr = (PANSI_STRING) ExAllocatePool(PagedPool,RtlUnicodeStringToAnsiSize(&(deviceExtension->SymbolicLinkName)));
	if(pstr != NULL)
		if(STATUS_SUCCESS != RtlUnicodeStringToAnsiString(pstr,&(deviceExtension->SymbolicLinkName),FALSE))
		{
			ExFreePool(pstr);
			pstr = NULL;
		}

	deviceExtension->HandleCount++;
	//DbgPrint("1394CMDR: %s: Create: %d handles total",(pstr ? pstr->Buffer : "<<NULL>>"), deviceExtension->HandleCount);

	if(pstr)
		ExFreePool(pstr);

    EXIT("t1394Cmdr_Create", ntStatus);
    return(ntStatus);
} // t1394Cmdr_Create

/*
 * A good old-fashioned Close Function
 */

NTSTATUS
t1394Cmdr_Close(
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    NTSTATUS    ntStatus = STATUS_SUCCESS;
    PDEVICE_EXTENSION   deviceExtension = DeviceObject->DeviceExtension;
	PCAMERA_STATE cameraState = &(deviceExtension->CameraState);
	PANSI_STRING pstr;

    ENTER("t1394Cmdr_Close");

	pstr = (PANSI_STRING) ExAllocatePool(PagedPool,RtlUnicodeStringToAnsiSize(&(deviceExtension->SymbolicLinkName)));
	if(pstr != NULL)
		if(STATUS_SUCCESS != RtlUnicodeStringToAnsiString(pstr,&(deviceExtension->SymbolicLinkName),FALSE))
		{
			ExFreePool(pstr);
			pstr = NULL;
		}

	deviceExtension->HandleCount--;
	//DbgPrint("1394CMDR: %s: Close: %d handles total",(pstr ? pstr->Buffer : "<<NULL>>"), deviceExtension->HandleCount);

	if(pstr)
		ExFreePool(pstr);

    return(ntStatus);
} // t1394Cmdr_Close

NTSTATUS
t1394Cmdr_SubmitIrpSynch(
    IN PDEVICE_OBJECT       DeviceObject,
    IN PIRP                 Irp,
    IN PIRB                 Irb
    )
{
    NTSTATUS            ntStatus = STATUS_SUCCESS;
    KEVENT              Event;
    PIO_STACK_LOCATION  NextIrpStack;

    ENTER("t1394Cmdr_SubmitIrpSynch");

    TRACE(TL_TRACE, ("DeviceObject = 0x%x\n", DeviceObject));
    TRACE(TL_TRACE, ("Irp = 0x%x\n", Irp));
    TRACE(TL_TRACE, ("Irb = 0x%x\n", Irb));

    if (Irb) {

        NextIrpStack = IoGetNextIrpStackLocation(Irp);
        NextIrpStack->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
        NextIrpStack->Parameters.DeviceIoControl.IoControlCode = IOCTL_1394_CLASS;
        NextIrpStack->Parameters.Others.Argument1 = Irb;
    }
    else {

        IoCopyCurrentIrpStackLocationToNext(Irp);
    }

    KeInitializeEvent(&Event, SynchronizationEvent, FALSE);

    IoSetCompletionRoutine( Irp,
                            t1394Cmdr_SynchCompletionRoutine,
                            &Event,
                            TRUE,
                            TRUE,
                            TRUE
                            );

    ntStatus = IoCallDriver(DeviceObject, Irp);

    if (ntStatus == STATUS_PENDING) {

        TRACE(TL_TRACE, ("t1394Cmdr_SubmitIrpSynch: Irp is pending...\n"));
        
        KeWaitForSingleObject( &Event,
                               Executive,
                               KernelMode,
                               FALSE,
                               NULL
                               );

    }

    ntStatus = Irp->IoStatus.Status;

    EXIT("t1394Cmdr_SubmitIrpSynch", ntStatus);
    return(ntStatus);
} // t1394Cmdr_SubmitIrpSynch

NTSTATUS
t1394Cmdr_SynchCompletionRoutine(
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp,
    IN PKEVENT          Event
    )
{
    NTSTATUS        ntStatus = STATUS_SUCCESS;

    ENTER("t1394Cmdr_SynchCompletionRoutine");

    if (Event)
        KeSetEvent(Event, 0, FALSE);
    
    EXIT("t1394Cmdr_SynchCompletionRoutine", ntStatus);
    return(STATUS_MORE_PROCESSING_REQUIRED);
} // t1394Cmdr_SynchCompletionRoutine

void
t1394Cmdr_CancelIrp(
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    KIRQL               Irql;
    PBUS_RESET_IRP      BusResetIrp;
    PDEVICE_EXTENSION   deviceExtension;

    ENTER("t1394Cmdr_CancelIrp");

    deviceExtension = DeviceObject->DeviceExtension;

    KeAcquireSpinLock(&deviceExtension->ResetSpinLock, &Irql);

    BusResetIrp = (PBUS_RESET_IRP) deviceExtension->BusResetIrps.Flink;

    TRACE(TL_TRACE, ("Irp = 0x%x\n", Irp));

    while (BusResetIrp) {

        TRACE(TL_TRACE, ("Cancelling BusResetIrp->Irp = 0x%x\n", BusResetIrp->Irp));

        if (BusResetIrp->Irp == Irp) {

            RemoveEntryList(&BusResetIrp->BusResetIrpList);
            ExFreePool(BusResetIrp);
            break;
        }
        else if (BusResetIrp->BusResetIrpList.Flink == &deviceExtension->BusResetIrps) {
            break;
        }
        else
            BusResetIrp = (PBUS_RESET_IRP)BusResetIrp->BusResetIrpList.Flink;
    }

    KeReleaseSpinLock(&deviceExtension->ResetSpinLock, Irql);

    IoReleaseCancelSpinLock(Irp->CancelIrql);

    Irp->IoStatus.Status = STATUS_CANCELLED;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

  	EXIT("t1394Cmdr_CancelIrp", STATUS_SUCCESS);
} // t1394Cmdr_CancelIrp

/*
 * ReadRegister
 *
 * Reads a quadlet from the camera registers at the (absolute) offset ulOffset
 */

NTSTATUS
t1394Cmdr_ReadRegister( 
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp,
	IN ULONG			ulOffset,
	OUT PUCHAR			pData
    )
{
	IO_ADDRESS DestinationAddress;
	PDEVICE_EXTENSION deviceExtension = DeviceObject->DeviceExtension;
	PIRB pIrb;
	PMDL pMdl;
	NTSTATUS ntStatus = STATUS_SUCCESS;

	//DbgPrint("1394CMDR: enter readRegister(0x%08x,0x%08x)\n",ulOffset,pData);

	pData[0] = pData[1] = pData[2] = pData[3] = 0;
	RtlZeroMemory(&DestinationAddress,sizeof(IO_ADDRESS));
	DestinationAddress.IA_Destination_Offset.Off_High = 0xffff;
	DestinationAddress.IA_Destination_Offset.Off_Low = ulOffset;
	pIrb = ExAllocatePool(NonPagedPool, sizeof(IRB));
	if (!pIrb) {
		DbgPrint("1394CMDR: ReadRegister: insufficient resources\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
	} else {
		pIrb->FunctionNumber = REQUEST_ASYNC_READ;
		pIrb->Flags = 0;
		pIrb->u.AsyncRead.DestinationAddress = DestinationAddress;
		pIrb->u.AsyncRead.nNumberOfBytesToRead = 4;
		pIrb->u.AsyncRead.nBlockSize = 0;
		pIrb->u.AsyncRead.fulFlags = 0;
		pIrb->u.AsyncRead.ulGeneration = deviceExtension->GenerationCount;
		pMdl = MmCreateMdl(NULL, pData, 4);
		MmBuildMdlForNonPagedPool(pMdl);
		pIrb->u.AsyncRead.Mdl = pMdl;

		ntStatus = t1394Cmdr_SubmitIrpSynch(deviceExtension->StackDeviceObject, Irp, pIrb);
		if(!NT_SUCCESS(ntStatus))
			DbgPrint("1394CMDR: ReadRegister: error %08x on SubmitIrpSynch\n",ntStatus);
	}

	if (pMdl)
		ExFreePool(pMdl);

	if (pIrb)
		ExFreePool(pIrb);

	return ntStatus;
}

/*
 * ReadRegister
 *
 * Writes a quadlet from pData into the camera registers at the (absolute) offset ulOffset
 */


NTSTATUS
t1394Cmdr_WriteRegister( 
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp,
	IN ULONG			ulOffset,
	IN PUCHAR			pData
    )
{
	IO_ADDRESS DestinationAddress;
	PDEVICE_EXTENSION deviceExtension = DeviceObject->DeviceExtension;
	PIRB pIrb;
	PMDL pMdl;
	NTSTATUS ntStatus = STATUS_SUCCESS;

	RtlZeroMemory(&DestinationAddress,sizeof(IO_ADDRESS));
	DestinationAddress.IA_Destination_Offset.Off_High = 0xffff;
	DestinationAddress.IA_Destination_Offset.Off_Low = ulOffset;
	pIrb = ExAllocatePool(NonPagedPool, sizeof(IRB));

	if (!pIrb) {
		DbgPrint("WriteRegister: insufficient resources\n");
		ntStatus = STATUS_INSUFFICIENT_RESOURCES;
	} else {
		pIrb->FunctionNumber = REQUEST_ASYNC_WRITE;
		pIrb->Flags = 0;
		pIrb->u.AsyncWrite.DestinationAddress = DestinationAddress;
		pIrb->u.AsyncWrite.nNumberOfBytesToWrite = 4;
		pIrb->u.AsyncWrite.nBlockSize = 0;
		pIrb->u.AsyncWrite.fulFlags = 0;
		pIrb->u.AsyncRead.ulGeneration = deviceExtension->GenerationCount;
		pMdl = MmCreateMdl(NULL, pData, 4);
		MmBuildMdlForNonPagedPool(pMdl);
		pIrb->u.AsyncRead.Mdl = pMdl;
		ntStatus = t1394Cmdr_SubmitIrpSynch(deviceExtension->StackDeviceObject, Irp, pIrb);
		if(!NT_SUCCESS(ntStatus))
			DbgPrint("WriteRegister: error %08x on SubmitIrpSynch\n",ntStatus);
	}

	if (pMdl)
		ExFreePool(pMdl);

	if (pIrb)
		ExFreePool(pIrb);

	return ntStatus;
}



