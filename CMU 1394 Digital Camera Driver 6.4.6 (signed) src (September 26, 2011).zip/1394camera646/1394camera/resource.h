//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by 1394camera.rc
//
#define IDAPPLY                         3
#define IDREFRESH                       4
#define IDD_DEBUG                       102
#define IDD_CONTROL_PANE                103
#define IDR_CONTROL_MENU                104
#define IDD_ADVANCED_CONTROL            105
#define IDD_PARTIAL_SCAN                106
#define IDR_ACCELERATOR1                107
#define IDR_CONTROL_ACCEL               107
#define IDR_ICON1                       128
#define IDC_SLIDER_DLL                  1000
#define IDC_SLIDER_SYS                  1001
#define IDC_DLL_DESCRIPTION             1002
#define IDC_SYS_DESCRIPTION             1003
#define IDC_CHECK_DEFAULT               1004
#define IDC_SLIDER1                     1005
#define IDC_SLIDER2                     1006
#define IDC_SLIDER_FEEDBACK1            1007
#define IDC_SLIDER_FEEDBACK2            1008
#define IDC_TITLE                       1009
#define IDC_BUT_ADVANCED                1010
#define IDC_BUT_ONOFF                   1011
#define IDC_BUT_ONEPUSH                 1012
#define IDC_BUT_AUTO_MAN                1013
#define IDC_BUT_POLL                    1014
#define IDC_INQ_PRES                    1015
#define IDC_INQ_ONEPUSH                 1016
#define IDC_INQ_READ                    1017
#define IDC_INQ_ONOFF                   1018
#define IDC_INQ_AUTO                    1019
#define IDC_INQ_MANUAL                  1020
#define IDC_STA_PRES                    1021
#define IDC_STA_ONEPUSH                 1022
#define IDC_STA_ONOFF                   1023
#define IDC_STA_AUTO                    1024
#define IDC_STA_MANUAL                  1025
#define ID_FIRST_CONTROL_PANE           1026
#define ID_LAST_CONTROL_PANE            1090
#define IDC_EDIT_INQUIRY                1092
#define IDC_EDIT_STATUS                 1093
#define IDC_INQUIRY_BIT                 1094
#define IDC_SLIDER_WIDTH                1095
#define IDC_SLIDER_HEIGHT               1096
#define IDC_SLIDER_LEFT                 1099
#define IDC_SLIDER_TOP                  1100
#define IDC_COMBO_MODE                  1108
#define IDC_COMBO_COLORCODE             1109
#define IDC_WIDTH_FEEDBACK              1110
#define IDC_PIXFRAME_FEEDBACK           1111
#define IDC_HEIGHT_FEEDBACK             1112
#define IDC_LEFT_FEEDBACK               1113
#define IDC_TOP_FEEDBACK                1114
#define IDC_BYTESFRAME_FEEDBACK         1115
#define IDC_BYTESPACKET_FEEDBACK        1116
#define IDC_PACKETSFRAME_FEEDBACK       1117
#define IDC_ERROR_FEEDBACK              1118
#define IDC_SLIDER_BYTESPACKET          1119
#define IDC_ABSCTL                      1120
#define IDC_DATADEPTH_FEEDBACK          1120
#define IDC_ABSMIN                      1121
#define IDC_ABSMAX                      1122
#define IDC_COLORFILTER_FEEDBACK        1122
#define IDC_FRAMEINTERVAL_FEEDBACK      1124
#define ID_FILE_SAVEDEFAULTVIEW         40001
#define ID_FILE_LOADDEFAULTVIEW         40002
#define ID_FILE_CLOSETHISWINDOW         40003
#define ID_FILE_CLOSE                   40003
#define ID_VIEW_ALLCONTROLS             40004
#define ID_VIEW_CONTROL_START           40005
#define ID_VIEW_CONTROL_END             40069
#define ID_CONTROL_POLLALL              40070
#define ID_VIEW_STRICT_PRESENT          40071
#define ID_VIEW_LOOSE_PRESENT           40072
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40073
#define _APS_NEXT_CONTROL_VALUE         1122
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
